# coding: utf-8
import glob
import logging
import os
import os.path
import pstats
import time

import yappi

logger = logging.getLogger(__name__)

PROFILING_RESULT_DIR = 'profiling_result'


def setup_for_gevent(yappi_mod=None):
    import gevent
    yappi.set_clock_type('cpu')
    yappi.set_context_id_callback(lambda: id(gevent.getcurrent()))
    yappi.set_context_name_callback(
        lambda: gevent.getcurrent().__class__.__name__)


def start_profiling():
    setup_for_gevent(yappi)
    logger.warn('Starting profiling...')
    yappi.start()


def stop_profiling(dir=PROFILING_RESULT_DIR):
    logger.warn('Stopping profiling...')
    yappi.stop()
    stats = yappi.get_func_stats()
    master_pid = os.getppid()
    worker_pid = os.getpid()
    fpath = '%d-%d_%d.pstats' % (master_pid, worker_pid, int(time.time()))
    fpath = os.path.join(dir, fpath)
    try:
        os.mkdir(dir, 0755)
    except OSError:
        pass
    stats.save(fpath, 'pstat')
    logger.warn('Profiling result saved to: %s', fpath)


def aggregate_child_process_stats(dir=PROFILING_RESULT_DIR):
    logger.warn('Merging children process stats into one...')
    master_pid = os.getpid()
    pattern = '%d-*.pstats' % master_pid
    children_stats_files = glob.glob(os.path.join(dir, pattern))
    s = pstats.Stats(*children_stats_files)
    fpath = os.path.join(dir, '%d_%d.pstats' % (master_pid, int(time.time())))
    s.dump_stats(fpath)
    logger.warn('Merged profiling result saved to: %s', fpath)
