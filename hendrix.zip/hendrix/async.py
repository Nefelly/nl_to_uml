# coding: utf-8
import logging
import inspect

import celery
import celery.signals
import celery.utils.log

from .conf import setting
from .log import Logging
from .db import DBManager

get_task_logger = celery.utils.log.get_task_logger

logger = logging.getLogger(__name__)


class HendrixCeleryWorkerLogging(Logging):
    def setup(self, *args, **kwargs):
        super(HendrixCeleryWorkerLogging, self).setup(*args, **kwargs)
        return self.already_setup


class HendrixCelery(celery.Celery):
    def __init__(self, *args, **kwargs):
        super(HendrixCelery, self).__init__(*args, **kwargs)

        if not self._config_source:
            self._config_source = setting

        self._setup_logging()
        if 'DB_SETTINGS' in setting:
            self.db_manager = DBManager()
            self.db_manager.initall()
        self._connect_celery_signals()
        self._setup_accept_pickle()

    def _setup_accept_pickle(self):
        if 'pickle' not in self.conf.accept_content:
            self.conf.accept_content.insert(0, 'pickle')

    def _setup_logging(self, lvl=logging.INFO, incremental=False):
        if not hasattr(self, '_hendrix_log'):
            self._hendrix_log = HendrixCeleryWorkerLogging(self.main)
        self._hendrix_log.setup(lvl, incremental=incremental)

    def _connect_celery_signals(self):
        def before_task_publish_handler(**kwargs):
            name = kwargs.pop('sender')
            logger.info('publishing %r: %r', name, kwargs)

        def setup_logging_handler(**kwargs):
            lvl = kwargs.get('loglevel', logging.INFO)
            self._setup_logging(lvl, True)

        s = celery.signals
        s.setup_logging.connect(setup_logging_handler, weak=False)
        s.before_task_publish.connect(before_task_publish_handler, weak=False)


class AsyncInitError(Exception):
    pass


class MissingTaskRouteSettings(AsyncInitError):
    """ When missing of `task_routes`, raise this exception"""
    def __init__(self):
        message = '`task_routes` is needed.'
        super(MissingTaskRouteSettings, self).__init__(message)


class MissingQueueName(AsyncInitError):
    """ When missing of `queue name` in the value dict of `task_routes`,
    raise this exception
    """
    def __init__(self, task_name):
        message = 'Task: {} - lack of queue name.'.format(task_name)
        super(MissingQueueName, self).__init__(message)


class InvalidQueueName(AsyncInitError):
    """ When the format of queue name is illegal, raise this exception"""
    def __init__(self, task_name, queue_name):
        message = \
            'Task: {} - invalid queue name: {}. The format of ' \
            .format(task_name, queue_name) + \
            'queue name is: servicename_queue, ex. sns.rts_tag'
        super(InvalidQueueName, self).__init__(message)


class HendrixTaskDispatcher(object):
    MissingTaskRouteSettings = MissingTaskRouteSettings
    MissingQueueName = MissingQueueName
    InvalidQueueName = InvalidQueueName

    def _validate_task_routes(self):
        """Validate the format of queue names in task routes.

        The correct format of the queue name is: (service_name)_(queue_name),
        Ex:     'sns.rts_tag'
        """
        for task_name, value_dict in self.task_routes.iteritems():
            queue_name = value_dict.get('queue', None)
            if not queue_name:
                raise self.MissingQueueName(task_name)
            _tuple = queue_name.split('.', 1)  # (group_name, package_name)
            if not (len(_tuple) == 2 and
                    _tuple[1].startswith(self.app.main + '_')):
                print _tuple
                raise self.InvalidQueueName(task_name, queue_name)

    def __init__(self, celery_app):
        self.app = celery_app

        def predicate(member):
            if not inspect.ismethod(member):
                return False
            argspec = inspect.getargspec(member)
            try:
                return argspec.args[0] == 'task_obj'
            except IndexError:
                return False
            return True

        for name, value in inspect.getmembers(self.__class__, predicate):
            task = self.app.task(bind=True)(value.__func__)
            object.__setattr__(self, name, task)

        if getattr(self, 'task_routes', None) is None:
            raise self.MissingTaskRouteSettings()
        try:
            self._validate_task_routes()
        except AsyncInitError as e:
            logger.error(str(e))
            raise e
        self.app.conf.task_routes = self.task_routes
