# coding: utf-8
from __future__ import absolute_import
import logging
import functools

from gevent import queue
from redis import (
    StrictRedis,
    BlockingConnectionPool,
)
from redis.client import StrictPipeline

from .metrics import Instrument, Timing, send_redis_op_metrics
from .context import g
from .conf import setting
from .app import get_current_app
from .util import BaseDBManager

logger = logging.getLogger(__name__)


def _make_redis_client(retry_on_timeout=True, instrument=False,
                       max_connections=30, socket_timeout=1,
                       socket_connect_timeout=0.1, block_timeout=1,
                       **kwargs):
    """ Generating redis client.

        Args:
            retry_on_timeout (bool): whether retry when timeout
            instrument (bool): whether use metrics or not
            max_connections (int): the upper limit of the redis connection pool
            socket_timeout (int): the seconds waiting for receiving response
            socket_connect_timeout (int): the timeout seconds making connection
            block_timeout (int): the timeout seconds waiting for getting
                a connection from pool

        Returns:
            RedisClientProxy: the object of the redis client proxy
    """
    client = RedisClientProxy(
        retry_on_timeout=retry_on_timeout,
        max_connections=max_connections,
        socket_timeout=socket_timeout,
        socket_connect_timeout=socket_connect_timeout,
        block_timeout=block_timeout,
        **kwargs
    )

    if instrument:
        client._instrument = Instrument(
            client=client,
            server=client._server,
            service_name=get_current_app().full_name,
            metric_key='redis.conn',
            type='redis')
        client._instrument.start()
    return client


class RedisHelper(object):
    def metrics_with_func(self, method, is_pipeline=False):
        @functools.wraps(method)
        def wrapper(*args, **kwargs):
            command_name = args[0].lower() if not is_pipeline else 'pipeline'
            keys = args[1:] if not is_pipeline else ''
            srv_addr = self._server if not is_pipeline \
                else (self.connection_pool.connection_kwargs.get('host'),
                      self.connection_pool.connection_kwargs.get('port'))
            try:
                t = Timing(None)
                t.begin()
                res = method(*args, **kwargs)
                t.end()
                is_exc = isinstance(res, BaseException)

                if not is_exc:
                    return res
                raise res
            except Exception as e:
                if not is_pipeline:
                    logger.exception(
                        'error %r redis [%r:%r]: %r %r',
                        command_name, srv_addr[0], srv_addr[1], args, kwargs)
                else:
                    logger.exception(
                        'error %r redis [%r:%r]',
                        command_name, srv_addr[0], srv_addr[1])
                t.end()
                is_exc = True
                raise e
            finally:
                send_redis_op_metrics(
                    ctx=g.get_current_ctx(), op_name=command_name,
                    cost=t.value, exc=is_exc, keys=keys,
                    srv_addr=srv_addr
                )
        return wrapper


class RedisClientProxy(RedisHelper):
    _proxied_cls = StrictRedis
    _proxied_func = ['execute_command', 'pipeline']
    _connection_pool_cls = BlockingConnectionPool

    def __init__(self, block_timeout=2, **kwargs):
        self._proxied = \
            self._gen_redis_client(timeout=block_timeout, **kwargs)
        self._server = (kwargs.get('host'), kwargs.get('port'))
        for func_name in self._proxied_func:
            func = self._wrap_func(func_name)
            setattr(self._proxied, func_name, func)

    def __getattr__(self, name):
        return getattr(self._proxied, name)

    def _wrap_func(self, proxy_func):
        func = getattr(self._proxied, proxy_func)
        if proxy_func == 'execute_command':
            func = self.metrics_with_func(func)
        elif proxy_func == 'pipeline':
            func = self._proxy_pipeline(func)
        return func

    def _gen_redis_client(self, timeout, **kwargs):
        connection_pool = self._connection_pool_cls(
            timeout=timeout, queue_class=queue.LifoQueue, **kwargs)
        return self._proxied_cls(connection_pool=connection_pool)

    def _proxy_pipeline(self, func):
        @functools.wraps(func)
        def wrapper(transaction=True, shard_hint=None):
            return StrictRedisPipeline(
                self.connection_pool, self.response_callbacks,
                transaction, shard_hint)
        return wrapper


class StrictRedisPipeline(StrictPipeline, RedisHelper):
    """The class focus on two points:

        1. Because of the problem of `` TypeError `` when use ``Pipeline`` in
           `` Redis-py ``, It's necessory patching function ``parse_response``
           in `` BasePipelin ``

        2. Add sending metrics when using Pipeline

    Using Proxy may cause Memory Leak, so this class inherit class
    `` StrictPipeline `` to achieve the aim above.
    """
    def parse_response(self, connection, command_name, **options):
        try:
            return super(StrictRedisPipeline, self) \
                .parse_response(connection, command_name, **options)
        except TypeError:
            connection.disconnect()
            raise

    def execute(self, raise_on_error=True):
        _func = super(StrictRedisPipeline, self).execute
        func = self.metrics_with_func(_func, is_pipeline=True)
        return func(raise_on_error=raise_on_error)


class RedisSession(BaseDBManager):
    _url_template = 'redis://:{password}@{host}:{port}/{db}'

    @property
    def settings(self):
        return setting.REDIS_SETTINGS

    def _initdb(self, name):
        redis_setting = self.settings[name]
        if 'url' in redis_setting:
            raise ValueError('redis setting `url` is not supported.')
        self[name] = _make_redis_client(**redis_setting)
        logger.info('redis: %s inited. Settings: %r', name, redis_setting)


redis_session = RedisSession()
