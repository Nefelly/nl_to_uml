# encoding=utf8
import functools
import socket
import time
import logging
import json
import os
import sys
import urlparse

logger = logging.getLogger(__name__)

_HOSTNAME = None


def get_hostname():
    global _HOSTNAME
    if _HOSTNAME is None:
        _HOSTNAME = socket.gethostname()
        try:
            in_file = open("/etc/hostname").read().strip()
            if in_file and _HOSTNAME != in_file:
                logger.error("hostname inconsistency: %r (kern) != %r (file)",
                             _HOSTNAME, in_file)
                _HOSTNAME = in_file  # file has the precedence
        except Exception as e:
            logger.error(e)
    return _HOSTNAME


def dsn2srv(dsn):
    parsed = urlparse.urlparse(dsn)
    return parsed.hostname, parsed.port


class CachedProperty(object):
    """Decorator like python built-in ``property``, but it results only
    once call, set the result into decorated instance's ``__dict__`` as
    a static property.
    """

    def __init__(self, fn):
        self.fn = fn
        self.__doc__ = fn.__doc__

    def __get__(self, inst, cls):
        if inst is None:
            return self
        val = inst.__dict__[self.fn.__name__] = self.fn(inst)
        return val

cached_property = CachedProperty  # alias


class EnvvarReader(dict):
    """The instance of this ``EnvvarReader`` can load the settings
    from the ``setting.py``, It will try to get the config from
    environ variables, if not get, then set the config to the default
    value"""
    __uninitialized = object()

    def __init__(self, *envvars):
        for ev in envvars:
            ev_norm = self._normalize(ev)
            if ev != ev_norm:
                raise ValueError('invalid envvar name: {!r}'.format(ev))
            dict.__setitem__(self, ev_norm, self.__uninitialized)

    @cached_property
    def configured(self):
        return any([self[k] for k in self])

    def _normalize(self, varname):
        return varname.strip()

    def __getitem__(self, key):
        key = self._normalize(key)
        value = dict.__getitem__(self, key)
        if value is self.__uninitialized:
            value = os.getenv(key, None)
            dict.__setitem__(self, key, value)
        return value

    __getattr__ = __getitem__

    def get(self, key, default=None):
        val = self.__getitem__(key)
        if val is not None:
            return val
        return default

    def get_int(self, key, default=None):
        value = self.__getitem__(key)
        if value is not None:
            return int(value)
        return default

    def get_float(self, key, default=None):
        value = self.__getitem__(key)
        if value is not None:
            return float(value)
        return default

    def get_bool(self, key, default=False):
        value = self.__getitem__(key)
        if value not in (None, '', '0', 'False', 'false'):
            return True
        return default

    def get_json(self, key, default=None):
        value = self.__getitem__(key)
        if value is not None:
            return json.loads(value)
        default = default or {}
        return default

    def __setitem__(self, key, value):
        raise RuntimeError('setting envvar not supported')

    __setattr__ = __setitem__


def import_string(imp_name):
    imp_name = str(imp_name).replace(':', '.')
    try:
        __import__(imp_name)
    except ImportError:
        if '.' not in imp_name:
            raise
    else:
        return sys.modules[imp_name]
    mod_name, obj_name = imp_name.rsplit('.', 1)
    try:
        mod = __import__(mod_name, None, None, [obj_name])
    except ImportError:
        mod = import_string(mod_name)
    try:
        return getattr(mod, obj_name)
    except AttributeError as e:
        raise ImportError(e)


class BaseDBManager(dict):
    @property
    def settings(self):
        raise NotImplementedError()

    def _initdb(self, name):
        raise NotImplementedError()

    def initdb(self, name):
        if not self.get(name):
            self._initdb(name)
        else:
            logger.warning('db: %r already inited', name)

    def initall(self):
        for db in self.settings:
            self.initdb(db)

    def __getitem__(self, key):
        if key not in self and key in self.settings:
            self.initdb(key)
        return super(BaseDBManager, self).__getitem__(key)

    def __getattr__(self, name):
        try:
            return self.__getitem__(name)
        except KeyError:
            raise AttributeError(name)


class EnumItem(object):
    def __init__(self, name, value, display=u''):
        self.name = name
        self.value = value
        self.display = display

    def __str__(self):
        return self.display.encode('utf-8')

    def __repr__(self):
        if self.display:
            r = u'EnumItem({0.name}): <{0.value}, {0.display}>'.format(self)
        else:
            r = u'EnumItem({0.name}): <{0.value}>'.format(self)
        return r.encode('utf-8')


class Enum(object):
    """A simple data structure which aims to create and use consts easily.

    usage::

        GENDER = Enum(
            ('MALE', 0, u'男'),
            ('FEMALE', 1, u'女'),
            ('UNKNOWN', 2, u'未知'),
        )

    The first item is the name of the const, the second item is the value,
    the third one is the annotation about this const.

    The developers can get the value of a const like this::

        male = GENDER.MALE

    """
    def __init__(self, *items):
        self._items = {}
        values = []
        for i in items:
            display = ''
            if len(i) == 2:
                name, value = i
            elif len(i) == 3:
                name, value, display = i
            else:
                raise ValueError(i)
            if value in values:
                raise ValueError('duplicate value: {!r}'.format(value))
            values.append(value)
            i = EnumItem(name, value, display)
            self._items[name] = i

    def __repr__(self):
        return 'Enum: <{}>'.format(', '.join(self._items.keys()))

    def __getattr__(self, name):
        try:
            return self._items[name].value
        except KeyError:
            raise AttributeError(name)

    def __getitem__(self, key):
        return self._items[key].value

    def items(self):
        return self._items.values()

    def values(self):
        return set([i.value for i in self._items.values()])

    def get_by_value(self, val):
        for v in self.items():
            if v.value == val:
                return v
        raise ValueError('invalid value: {!r}'.format(val))


def unix_ts_utc(dt):
    ts = int(time.mktime(dt.utctimetuple()))
    return ts


def parse_params(thrift_struct):
    params = dict()
    for k in thrift_struct.__dict__:
        if not k.startswith('__'):
            v = thrift_struct.__dict__[k]
            if v is not None:
                params[k] = v
    return params


class AttributeDictMixin(object):
    """Mixin for Mapping interface that adds attribute access.

    I.e., `d.key -> d[key]`).
    """

    def __getattr__(self, k):
        # type: (str) -> Any
        """`d.key -> d[key]`."""
        try:
            return self[k]
        except KeyError:
            raise AttributeError(
                '{0!r} object has no attribute {1!r}'.format(
                    type(self).__name__, k))

    def __setattr__(self, key, value):
        # type: (str, Any) -> None
        """`d[key] = value -> d.key = value`."""
        self[key] = value


class AttributeDict(dict, AttributeDictMixin):
    pass


def get_pkg_name(*sub):
    """Get current package name.

    Args:
        sub: Sub package names, if not provided, will return the top
             level package name.

    Returns:
        A string of the package name.
    """
    pkg_toplvl = __name__.split('.', 1)[0]
    if not sub:
        return pkg_toplvl
    return '.'.join([pkg_toplvl] + list(sub))


def concat_dict(*ds):
    """
    Concat dict (happily) together

    Args:
        ds: One or more dict needs to be promiscuous

    Returns:
        A dict (obviously)

    Doctest:

        >>> concat_dict({'a': 1, 'b': 2}, {'c': 3})
        {'a': 1, 'c': 3, 'b': 2}
        >>> concat_dict({'one': 1})
        {'one': 1}
        >>> concat_dict({'a': 1, 'b': 2}, {'b': 3})
        {'a': 1, 'b': 3}
        >>> concat_dict()
        {}
    """
    rv = []
    if len(ds) == 1:
        return ds[0]
    for d in ds:
        rv.extend(d.items())
    return dict(rv)


def memoize(f):
    _res_mapping = {}

    @functools.wraps(f)
    def wrapper(*args, **kwargs):
        key = args + tuple(sorted(kwargs.items()))
        try:
            return _res_mapping[key]
        except KeyError:
            _res_mapping[key] = value = f(*args, **kwargs)
            return value
    return wrapper
