# coding: utf-8
"""
Usage::

    # schema config dict
    schema = {
        'asura': {
            '_srv': 'influxdb',
            '_opts': {
                'url': 'influxdb://localhost:8086',
                'db_name': 'asura',
                'udp_enabled': True,
                'udp_port': 8099,
            },
            'api.calls': {
                'tags': [
                    'method',
                    'endpoint',
                    'hostname',
                ],
                'fields': [
                    'value',
                    'rid',
                ],
                'precision': 's',
            },
        },
    }

    metrics = Metrics(schema)

    # commit metrics value
    metrics['api.calls'].\
        tags(method='GET', endpoint='api_v1.message-detect',
             hostname=metrics.HOSTNAME).\
        values(rid=request.id).\
        commit(1)

    # use `Metrics.timing()` context manager to commit operation's cost (in ms)
    with metrics['cache.ops'].\
            tags(op='set', hostname=metrics.HOSTNAME).\
            values(key='cache_key').\
            timing():
        return cache.set('cache_key', 'cache_value')
"""

from collections import deque
from contextlib import contextmanager
from functools import partial
import logging
import socket
import time

try:
    import gevent.monkey
    gevent_patched = gevent.monkey.is_module_patched('threading')
except ImportError:
    gevent_patched = False
if gevent_patched:
    import gevent
else:
    import threading
from influxdb import InfluxDBClient

from .conf import setting
from .util import dsn2srv, cached_property

logger = logging.getLogger(__name__)


class MetricsError(Exception):
    pass


class InvalidDataError(MetricsError):
    pass


class BaseInstrument(object):
    __slots__ = ['client', 'value']

    def __init__(self, client):
        self.client = client
        self.value = None

    def _reset(self):
        self.value = None

    def commit(self, ts=None):
        if self.value is None:
            logger.warning('nothing instrumented')
            return False
        try:
            return self.client.commit(self.value, ts)
        except Exception:
            logger.warning('failed to commit timed value', exc_info=True)
            return False
        finally:
            self._reset()


def make_ts_in_ms():
    return int(time.time() * 1000)


class Timing(BaseInstrument):
    __slots__ = ['_begin', 'make_ts']

    def __init__(self, client, make_ts=make_ts_in_ms):
        self.make_ts = make_ts
        super(Timing, self).__init__(client)
        self._begin = deque()
        self._reset()

    def begin(self):
        self._begin.append(self.make_ts())

    def end(self):
        try:
            b = self._begin.pop()
        except IndexError:
            logger.warning('`begin` should be called before `end`')
        else:
            self.value = self.make_ts() - b

    @contextmanager
    def __call__(self):
        self.begin()
        yield self
        self.commit()

    def commit(self, ts=None):
        self.end()
        return super(Timing, self).commit(ts)


class BaseMetricsClient(object):
    __slots__ = ['name', '_writer', '_write_opts']

    def __init__(self, name, writer, **write_opts):
        self.name = name
        self._writer = writer
        self._write_opts = write_opts

    def __repr__(self):
        return u'<{0.__class__.__module__}.{0.__class__.__name__}(' \
            '{0.name!r}, {0._writer!r}, {0._write_opts!r}) at {1}>'.\
            format(self, hex(id(self))).encode('utf-8')

    def _check_data(self):
        pass

    def write_opts(self, **opts):
        self._write_opts.update(opts)

    def make_payload(self, value, ts):
        raise NotImplementedError

    def commit(self, value, ts=None):
        try:
            payload = self.make_payload(value, ts)
        except InvalidDataError as e:
            logger.warning('invalid data on metrics committing: %s: %s',
                           e, (value, ts))
        except Exception:
            logger.warning('failed to make metrics data', exc_info=True)
        else:
            try:
                return self._writer.write(payload, **self._write_opts)
            except Exception:
                logger.warning(
                    'failed to write metrics payload: %r with ops: %r',
                    payload, self._write_opts, exc_info=True)
                return False
        return False


class InfluxDBSeries(BaseMetricsClient):
    __slots__ = ['timing', '_fields', '_tags', '_prec', '_field_data',
                 '_tag_data']

    def __init__(self, name, writer, fields, tags=None, prec=None):
        super(InfluxDBSeries, self).__init__(name, writer)
        self._fields = fields and set(fields) or set()
        if not self._fields:
            raise MetricsError('fields can\'t be empty')
        self._tags = tags and set(tags) or set()
        self._prec = prec

        self._field_data = {}
        self._tag_data = {}

        self.timing = Timing(self)

    def __repr__(self):
        return u'<{0.__class__.__module__}.{0.__class__.__name__}(' \
            '{0.name!r}, {0._writer!r}, {0._fields!r}, {0._tags!r}, ' \
            '{0._prec!r}, {0._write_opts!r}) with ({0._field_data!r}, ' \
            '{0._tag_data!r}) at {1}>'.\
            format(self, hex(id(self))).encode('utf-8')

    def tags(self, **kwargs):
        self._tag_data.update(kwargs)
        return self

    def values(self, value=None, **kwargs):
        self._field_data.update(kwargs)
        if value is not None:
            self._field_data['value'] = value
        return self

    def _check_data(self, value, ts):
        if not self._field_data:
            raise InvalidDataError('no value provided')
        diff = self._fields ^ set(self._field_data.keys())
        if diff:
            raise InvalidDataError(
                'fields invalid or missing: {!r}'.format(diff))
        diff = self._tags ^ set(self._tag_data.keys())
        if diff:
            raise InvalidDataError(
                'tags invalid or missing: {!r}'.format(diff))

    def make_payload(self, value, ts):
        self.values(value=value)
        self._check_data(value, ts)
        p = {
            'measurement': self.name,
            'fields': self._field_data,
        }
        if ts is not None:
            p['time'] = ts
        if self._tag_data:
            p['tags'] = self._tag_data
        if self._prec is not None:
            p['precision'] = self._prec
        return p


class BaseWriter(object):
    def write(self, payload, block=False):
        raise NotImplementedError


class InfluxDBWriter(BaseWriter):
    def __init__(self, transport):
        self.transport = transport

    def _write_points(self, points, **kwargs):
        logger.debug('sending metrics data: %r', points)
        try:
            if gevent_patched:
                to = gevent.Timeout(1)
                to.start()
            return self.transport.write_points(points, **kwargs)
        # pylint: disable=E0712
        except gevent.Timeout:
            # pylint: enable=E0712
            logger.warning('timeout writing metrics', exc_info=True)
        except Exception:
            logger.warning('failed writing metrics', exc_info=True)
        finally:
            if gevent_patched:
                to.cancel()
        return False

    def write(self, payload, block=False, **write_opts):
        if not setting.METRICS_ENABLED:
            return True
        if self.transport.use_udp:
            return self._write_points([payload], **write_opts)
        if not block:
            if gevent_patched:
                gevent.spawn(self._write_points, [payload], **write_opts)
            else:
                t = threading.Thread(target=self._write_points,
                                     args=([payload],), kwargs=write_opts)
                t.daemon = True
                t.start()
            return True
        return self._write_points([payload], **write_opts)


class Metrics(dict):
    RESERVED_NAMES = ('_opts', '_srv')
    HOSTNAME = socket.gethostname()

    def __init__(self, schemas):
        """
        :param dict schema: a schema containing client config::

            {
                'asura': {
                    '_srv': 'influxdb',
                    '_opts': {
                        'url': 'influxdb://localhost:8086',
                        'db_name': 'asura',
                        'udp_enabled': True,
                        'udp_port': 8099,
                    },
                    'api.calls': {
                        'tags': [
                            'method',
                            'endpoint',
                            'hostname',
                        ],
                        'fields': [
                            'value',
                            'rid',
                        ],
                        'precision': 's',
                    },
                },
            }

        Usage::

            metrics = Metrics(METRICS_SCHEMAS)
            metrics['api.calls'].\
                tags(method='GET', endpoint='api_v1.message-detect',
                     hostname=metrics.HOSTNAME).\
                values(rid=request.id).\
                commit(1)
        """
        self._schemas = schemas
        self._init_with_schemas(self._schemas)

    def _init_influxdb_client(self, name, writer, **opts):
        fields = opts.get('fields', [])
        if not fields:
            raise MetricsError('fields can\'t be empty')
        c = InfluxDBSeries(name, writer, opts['fields'], opts.get('tags', []),
                           opts.get('precision', None))
        return c

    def _init_with_schemas(self, schemas):
        for name, conf in schemas.iteritems():
            client_opts = conf.get('_opts', {})
            type_ = conf.get('_srv', 'influxdb')
            if type_ == 'influxdb':
                host, port = dsn2srv(client_opts['url'])
                host = socket.gethostbyname(host)
                use_udp = client_opts.get('udp_enabled', False)
                if use_udp:
                    trans = InfluxDBClient(
                        host, port, database=client_opts['db_name'],
                        use_udp=True, udp_port=client_opts['udp_port'])
                else:
                    trans = InfluxDBClient(
                        host, port, database=name, timeout=5)
                for series_name, opts in conf.iteritems():
                    if series_name in self.RESERVED_NAMES:
                        continue
                    w = InfluxDBWriter(trans)
                    self[series_name] = partial(
                        self._init_influxdb_client, series_name, w, **opts)

    def __getitem__(self, name):
        return dict.__getitem__(self, name)()

    def get(self, name, default=None):
        try:
            return self.__getitem__(name)
        except KeyError:
            return default

    @property
    def clients(self):
        return self.keys()


def send_api_metrics(ctx, exc=False):
    tags = {
        'api': ctx.api_name,
        'exc': exc,
        'success': not exc,
        'hostname': metrics.HOSTNAME,
        'source': ctx.client_host,
    }
    metrics['api.request'].\
        tags(**tags).\
        values(rid=ctx.req_id).\
        commit(ctx.api_cost)


def send_cache_op_metrics(ctx, op_name, srv_addr, keys, cost,
                          exc=False, timeout=False, retry=False):
    """Send cache operation metrics

    Args:
        ctx: A ``hendrix.context.Context`` instance, usually retrieved
            from ``g.get_current_ctx()``.
        op_name: The cache operation name, e.g. ``get``.
        srv_addr: A cache server address pair, e.g. ``('127.0.0.1', 11211)``.
        keys: A sequence of strings representing the cache keys.
        cost: Time cost by the cache operation in millisecond.
        exc: If the cache operation raised an exception.
        timeout: If the cache operation timed out.
        retry: If the cache operation is a retry.

    Returns:
        None

    Raises:
        None
    """
    try:
        tags = {
            'op': op_name,
            'hostname': metrics.HOSTNAME,
            'server': '%s:%d' % srv_addr,
            'api': ctx.api_name,
            'timeout': timeout,
            'exc': bool(exc),
            'retry': retry,
        }
        values = {
            'key': str(keys),
            'rid': ctx.req_id,
        }
        metrics['cache.op'].\
            tags(**tags).\
            values(**values).\
            commit(cost)
    except Exception:
        logger.exception('error sending cache op metrics')


def send_redis_op_metrics(ctx, op_name, srv_addr, keys, cost,
                          exc=False):
    try:
        tags = {
            'op': op_name,
            'hostname': metrics.HOSTNAME,
            'server': '%s:%d' % srv_addr,
            'api': ctx.api_name,
            'exc': bool(exc),
        }
        values = {
            'key': str(keys),
            'rid': ctx.req_id,
        }
        metrics['redis.op'].\
            tags(**tags).\
            values(**values).\
            commit(cost)
    except Exception:
        logger.exception('error sending redis op metrics')


metrics = Metrics(setting.METRICS_SCHEMAS)


class InvalidTypeError(Exception):
    def __init__(self, type):
        message = \
            'InvalidType: `type` should be in '\
            '("memcache", "redis", "thrift"), rather than "{}".'.format(type)
        super(InvalidTypeError, self).__init__(message)


class Instrument(object):
    """A class which spawn a background greenlet to sent metrics
    data about the connection pool to the influxdb."""
    _RESERVED_TYPE = ('memcache', 'redis', 'thrift')
    _instrumented = False
    InvalidTypeError = InvalidTypeError

    def __init__(self, client, metric_key, type,
                 server=None, service_name=None):
        self.client = client
        self.server = server
        if isinstance(server, (list, tuple, set)):
            self.server = '%s:%s' % server
        self.service_name = service_name
        self._metric_key = metric_key

        self._validate_type(type)
        self._type = type

    def _validate_type(self, type):
        if type not in self._RESERVED_TYPE:
            raise self.InvalidTypeError(type)

    @cached_property
    def metric_tags(self):
        from .app import get_current_app
        current_app = get_current_app()
        key = getattr(current_app, 'package_name', None) \
            or getattr(current_app, 'import_name', None)
        if not key:
            logger.warn('cannot get metric tags for metrics.')
        return setting.METRICS_SCHEMAS[key].get(
            self._metric_key, {}).get('tags', [])

    def _get_idle_count(self):
        """Get the sum number of the idle connections.

        Currently, Instrument supports three types to send metrics:

            1. memcache         ------- Based on dogpile
            2. redis            ------- Based on redis-py
            3. thrift connector ------- Based on ThriftConnectionPool class
        """
        if self._type == 'memcache':
            _count = len(self.client.client_pool.free)
        elif self._type == 'redis':
            _count = self.client.connection_pool.pool.qsize()
        elif self._type == 'thrift':
            total = self.client.max_size
            in_use = self.client.pool_size()
            _count = total - in_use
        return _count

    def _get_in_use_count(self):
        """Get the sum number of the busy connections.

        Currently, Instrument supports three types to send metrics:

            1. memcache         ------- Based on dogpile
            2. redis            ------- Based on redis-py
            3. thrift connector ------- Based on ThriftConnectionPool class
        """
        if self._type == 'memcache':
            _count = len(self.client.client_pool.used)
        elif self._type == 'redis':
            _count = len(self.client.connection_pool._connections)
        elif self._type == 'thrift':
            _count = self.client.pool_size()
        return _count

    def _gen_tag_dict(self):
        _dict = dict(used=True, hostname=metrics.HOSTNAME)
        # pylint: disable=not-an-iterable
        for key in self.metric_tags:
            value = getattr(self, key, None)
            if value and (not _dict.get(key, None)):
                _dict[key] = value
        # pylint: enable=not-an-iterable
        return _dict

    def _track_pool_size(self, interval=5.0):
        logger.info(
            'start sending %s pool size metrics every %.1f seconds',
            self._type, interval
        )
        while True:
            try:
                size_in_use, size_idle = \
                    self._get_in_use_count(), self._get_idle_count()
                _tag_dict = self._gen_tag_dict()
                metrics[self._metric_key].tags(**_tag_dict).commit(size_in_use)
                _tag_dict['used'] = False
                metrics[self._metric_key].tags(**_tag_dict).commit(size_idle)
            except Exception:
                logger.exception('error sending pool size for: %r',
                                 (self.service_name, self.client))
            gevent.sleep(interval)

    def start(self):
        if not self._instrumented:
            _exec = gevent.spawn(self._track_pool_size)
            if _exec.exception:
                logger.error(_exec.exception)
            self._instrumented = True
