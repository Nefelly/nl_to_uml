# coding: utf-8
import warnings
import sys
import logging
import logging.config
import json
import traceback
from contextlib import contextmanager

from .conf import setting
from .const import ENV_DEV
from .env import is_prod_env
from .util import get_hostname

FORMAT_SYSLOG = '%(name)s[%(process)d] %(message)s'
FORMAT_CONSOLE = '%(asctime)s %(levelname)-7s ' + FORMAT_SYSLOG


@contextmanager
def record_context(record, **attr):
    # Backup before changing the content of record,
    # or next handlers will choke on your dirty data
    _backup_dict = {}
    for key, value in attr.iteritems():
        _backup_dict[key] = value
    try:
        yield record
    finally:
        for key, value in _backup_dict.iteritems():
            setattr(record, key, value)


class HendrixFormatter(logging.Formatter):
    MSG_SEPARATOR = '@@'

    def _format_meta(self, record):
        meta = []

        def _add_meta(pat, vals):
            meta.append((pat, vals))

        if hasattr(record, 'api_ctx'):
            api_ctx = record.api_ctx
            _add_meta('rid:%s', _get_log_value(lambda: api_ctx.req_id))
            _add_meta('client:%s', _get_log_value(
                lambda: api_ctx.client_host, default='-'))
            _add_meta('api:%s', _get_log_value(lambda: api_ctx.api_name))

        meta_msg = ''
        if meta:
            meta_msg = '\t'.join([m[0] % m[-1] for m in meta])
        return meta_msg

    def _format_msg(self, record):
        msg = record.msg
        meta_msg = self._format_meta(record)
        if meta_msg:
            return meta_msg + ' ' + msg
        return msg

    def _format(self, record):
        if not isinstance(record.msg, basestring):
            record.msg = str(record.msg)
        record.msg = self.MSG_SEPARATOR + ' ' + record.msg
        record.msg = self._format_msg(record)
        try:
            return super(HendrixFormatter, self).format(record)
        except UnicodeError:
            if isinstance(record.msg, str):
                record.msg = record.msg.decode('utf-8', 'replace')
            if record.args:
                args = []
                for a in record.args:
                    if isinstance(a, str):
                        a = a.decode('utf-8', 'replace')
                    args.append(a)
                record.args = tuple(args)
            return super(HendrixFormatter, self).format(record)

    def format(self, record):
        with record_context(record, msg=record.msg):
            return self._format(record)


class HendrixPrefixedFormatter(HendrixFormatter):
    def __init__(self, prefix, *args, **kwargs):
        self.prefix = prefix
        super(HendrixPrefixedFormatter, self).__init__(*args, **kwargs)

    def format(self, record):
        with record_context(record, name=record.name):
            record.name = self.prefix + '.' + record.name
            return super(HendrixPrefixedFormatter, self).format(record)


class FallbackJsonEncoder(json.JSONEncoder):
    def default(self, o):  # pylint: disable=E0202
        try:
            return repr(o)
        except Exception:
            return super(FallbackJsonEncoder, self).default(o)


class HendrixJsonFormatter(logging.Formatter):
    """
    output log as json

    current json fields are:
    {
        'logger': 'rus', # logger name
        'level': 'ERROR', # log level
        'message': 'I do not expect this', # log message
        'asctime': '2017-05-26 13:02:57,498', # timestamp
        'exc_text': 'Traceback...', # exception info
        'req_id': '95acfa65db9e4e94ab2488303b176217', # request id
        'api_name': 'get_system_message ', # api name
        'api_args': [['Android', 1], {}], # api args
        'api_cost': 78, # request processing time, in milliseconds
        'client_host': 'sns-asura-message05', # RPC client hostname
        'hostname': 'sns-rms01', # server hostname
    }
    """

    def _prepare_meta(self, ctx):
        """
        prepare meta info as dict, for ultimate json log
        """

        # `api_args` may contain different data types, e.g. [['123', 1], {}],
        # which chokes Elasticsearch.
        # No need to do filter/aggregation on `api_args`, format it as string.
        try:
            api_args = [repr(a) if not isinstance(a, basestring) else a
                        for a in ctx.api_args]
        except Exception:
            api_args = []

        return {
            'req_id': ctx.req_id,
            'api_name': ctx.api_name,
            'api_args': api_args,
            'api_cost': ctx.api_cost,
            'client_host': ctx.client_host,
            'hostname': get_hostname()
        }

    def _format_msg(self, record):
        # Combine record.msg and record.args
        # to yield the 'message' field of our json
        try:
            raw_msg = record.getMessage()
        except UnicodeError:
            if isinstance(record.msg, str):
                record.msg = record.msg.decode('utf-8', 'replace')
            if record.args:
                args = []
                for a in record.args:
                    if isinstance(a, str):
                        a = a.decode('utf-8', 'replace')
                    args.append(a)
                record.args = tuple(args)
            raw_msg = record.getMessage()

        d = {
            'logger': record.name,
            'level': record.levelname,
            'message': raw_msg,
            'asctime': self.formatTime(record, self.datefmt),
        }

        # exception info
        if record.exc_text:
            d['exc_text'] = record.exc_text
        elif record.exc_info:
            d['exc_text'] = self.formatException(record.exc_info)

        # other meta data
        if hasattr(record, 'api_ctx'):
            d.update(self._prepare_meta(record.api_ctx))

        return json.dumps(d, separators=(',', ':'),
                          cls=FallbackJsonEncoder)

    def _format(self, record):
        record.msg = self._format_msg(record)
        # prevent record.msg from being formatted by record.args
        record.args = ()
        # change record.name for rsyslog to redirect
        record.name = 'json.' + record.name
        # prevent exc_text from being appended
        record.exc_info = None
        record.exc_text = ''

        try:
            return super(HendrixJsonFormatter, self).format(record)
        except Exception:
            traceback.print_exc()
            return ''

    def format(self, record):
        with record_context(
                record, msg=record.msg, args=record.args, name=record.name,
                exc_info=record.exc_info, exc_text=record.exc_text):
            return self._format(record)


class HendrixJsonPrefixedFormatter(HendrixJsonFormatter):
    def __init__(self, prefix, *args, **kwargs):
        self.prefix = prefix
        super(HendrixJsonPrefixedFormatter, self).__init__(*args, **kwargs)

    def format(self, record):
        with record_context(record, name=record.name):
            record.name = self.prefix + '.' + record.name
            return super(HendrixJsonPrefixedFormatter, self).format(record)


class Logging(object):
    _setup = False

    def __init__(self, package_name):
        self.package_name = package_name

    def _gen_syslog_config(self, lvl=logging.INFO, incremental=False):
        _dict = {
            'version': 1,
            'root': {
                'handlers': ['syslog_prefixed', 'syslog_json_prefixed'],
                'level': 'INFO',
            },
            'loggers': {
                self.package_name: {
                    'handlers': ['syslog', 'syslog_json'],
                    'propagate': False,
                    'level': lvl,
                },
                'hendrix': {
                    'handlers': ['syslog_prefixed', 'syslog_json_prefixed'],
                    'propagate': False,
                    'level': lvl,
                },
                'thriftpy': {
                    'handlers': ['syslog_prefixed', 'syslog_json_prefixed'],
                    'propagate': False,
                    'level': lvl,
                },
                'celery': {
                    'handlers': ['syslog_prefixed', 'syslog_json_prefixed'],
                    'propagate': False,
                    'level': lvl,
                },
            },
            'handlers': {
                'syslog': {
                    'level': lvl,
                    'class': 'logging.handlers.SysLogHandler',
                    'address': '/dev/log',
                    'facility': 'local6',
                    'formatter': 'syslog',
                },
                'syslog_prefixed': {
                    'level': lvl,
                    'class': 'logging.handlers.SysLogHandler',
                    'address': '/dev/log',
                    'facility': 'local6',
                    'formatter': 'syslog_prefixed',
                },
                'syslog_json': {
                    'level': lvl,
                    'class': 'logging.handlers.SysLogHandler',
                    'address': '/dev/log',
                    'facility': 'local6',
                    'formatter': 'syslog_json',
                },
                'syslog_json_prefixed': {
                    'level': lvl,
                    'class': 'logging.handlers.SysLogHandler',
                    'address': '/dev/log',
                    'facility': 'local6',
                    'formatter': 'syslog_json_prefixed',
                },
            },
            'formatters': {
                'syslog': {
                    '()': HendrixFormatter,
                    'format': FORMAT_SYSLOG,
                },
                'syslog_prefixed': {
                    '()': HendrixPrefixedFormatter,
                    'format': FORMAT_SYSLOG,
                    'prefix': self.package_name,
                },
                'syslog_json': {
                    '()': HendrixJsonFormatter,
                    'format': FORMAT_SYSLOG,
                },
                'syslog_json_prefixed': {
                    '()': HendrixJsonPrefixedFormatter,
                    'format': FORMAT_SYSLOG,
                    'prefix': self.package_name,
                },
            },
            'incremental': incremental,
        }
        return _dict

    def _gen_console_config(self, lvl=logging.DEBUG, incremental=False):
        _dict = {
            'version': 1,
            'root': {
                'handlers': ['console'],
                'level': 'INFO',
            },
            'loggers': {
                self.package_name: {
                    'handlers': ['console'],
                    'propagate': False,
                    'level': lvl,
                },
                'hendrix': {
                    'handlers': ['console_prefixed'],
                    'propagate': False,
                    'level': lvl,
                },
                'thriftpy': {
                    'handlers': ['console_prefixed'],
                    'propagate': False,
                    'level': lvl,
                },
                'celery': {
                    'handlers': ['console_prefixed'],
                    'propagate': False,
                    'level': lvl,
                },
            },
            'handlers': {
                'console': {
                    'level': lvl,
                    'class': 'logging.StreamHandler',
                    'formatter': 'console',
                },
                'console_prefixed': {
                    'level': lvl,
                    'class': 'logging.StreamHandler',
                    'formatter': 'console_prefixed',
                },
            },
            'formatters': {
                'console': {
                    '()': HendrixFormatter,
                    'format': FORMAT_CONSOLE,
                },
                'console_prefixed': {
                    '()': HendrixPrefixedFormatter,
                    'format': FORMAT_CONSOLE,
                    'prefix': self.package_name,
                },
            },
            'incremental': incremental,
        }
        return _dict

    def _update_log_config(self, log_dict, extra_log_config):
        """
        According to the params, add more log config settings.

        :param log_dict: the basic log config settings.
        :param extra_log_config: some special log setting that the Developers
                                wants to add.
        """
        if extra_log_config:
            for key, value_dict in extra_log_config.iteritems():
                if key not in ['formatters', 'handlers', 'loggers']:
                    raise KeyError(
                        "%r should in ['formatters', 'handlers', 'loggers']" %
                        key)
                for name, value in value_dict.iteritems():
                    if name in log_dict[key]:
                        warnings.warn(
                            "reconfiguring %r: %r with user defined one." %
                            (key, name))
                    log_dict[key][name] = value
        return log_dict

    def _gen_app_log_config(self, lvl=None, incremental=False):
        env = setting.HENDRIX_ENV
        if sys.platform == 'darwin':
            lvl = lvl or logging.DEBUG
            log_dict = self._gen_console_config(lvl, incremental=incremental)
            if is_prod_env():
                env = ENV_DEV  # syslog cannot be configured for macOS
        elif is_prod_env():
            lvl = lvl or logging.INFO
            log_dict = self._gen_syslog_config(lvl, incremental=incremental)
        else:
            lvl = lvl or logging.DEBUG
            log_dict = self._gen_console_config(lvl, incremental=incremental)

        extra_log_config = \
            setting.get('HENDRIX_LOG_DICT_CONFIG', {}).get(env, {})
        log_config = self._update_log_config(log_dict, extra_log_config)
        return log_config

    def setup(self, lvl=None, force=False, incremental=False):
        if self.already_setup and not (force or incremental):
            logging.getLogger(__name__).warning('ignore logger reconfiguring')
            return
        log_config = self._gen_app_log_config(lvl, incremental)
        logging.config.dictConfig(log_config)
        self.already_setup = True
        return self.already_setup

    @property
    def already_setup(self):
        return self._setup

    @already_setup.setter
    def already_setup(self, was_setup):
        self._setup = was_setup


def _get_log_value(func, fallback='-', default=None):
    """
    :param callable func: log value getter
    :param fallback: if exception happens when calling ``func``, this
                     value will be used instead
    :param default: if ``func`` returns a falsy value and this is not None,
                    it will be used instead
    """
    try:
        value = func()
    except Exception:
        # do not log, prevent endless loop
        value = fallback
    else:
        if not value and default is not None:
            value = default
    return value


def log_api_call(logger, ctx, exc=None, warn_only=False):
    log_data = [
        ('args:%r', _get_log_value(lambda: ctx.api_args)),
        ('cost:%dms', _get_log_value(lambda: ctx.api_cost)),
    ]
    kwargs = {
        'extra': {
            'api_ctx': ctx
        }
    }
    if exc is not None:
        if warn_only:
            kwargs['exc_info'] = True
            log = logger.warning
        else:
            log = logger.exception
    else:
        log = logger.info
    log('\t'.join([x[0] for x in log_data]), *[x[1] for x in log_data],
        **kwargs)
