# coding: utf-8

"""
thrift-connector
~~~~~~~~~~~~~~~~

Author: Sns-backend
----------------

This is a lightly thriftpy connection pool.

The user using thrifpy to rpc calling can use this library to create a TCP
connection pool to avoid to create TCP connection once the application need
to send a rpc calling.

It takes the place of the method `make_client` in thriftpy. It's easy to use:

```
from hendrix.thrift_connector import ThriftConnectionPool

client_pool = ThriftConnectionPool(
    host=host, port=port, service=service
)
client = client_pool.connect

# rpc calling
with client() as client:
    client.rpc_calling_method(*args, **kwargs)
```
"""
import time
import logging
import contextlib
import datetime
from itertools import count

from .metrics import metrics, Instrument

logger = logging.getLogger(__name__)


class BaseThriftClient(object):
    def __init__(self, host, port, transport, protocol, service,
                 keepalive=None, service_name=None):
        self.host = host
        self.port = port
        self.transport = transport
        self.protocol = protocol
        self.service = service
        self.thrift_client = self.get_thrift_client(service, protocol)
        self.keepalive = datetime.datetime.now() + \
            datetime.timedelta(seconds=keepalive) if keepalive else None
        self.service_name = service_name

    def __getattr__(self, name):
        func = getattr(self.thrift_client, name)

        def wrap(*args, **kwargs):
            with metrics['thrift.connection.ops'].\
                    tags(hostname=metrics.HOSTNAME,
                         endpoint=name,
                         service_name=self.service_name).\
                    timing():
                return func(*args, **kwargs)
        wrap.__name__ = name
        return wrap

    def is_expired(self):
        if self.keepalive:
            return datetime.datetime.now() > self.keepalive
        return False

    def is_connection_available(self):
        """Before giving the connection to the user,

        testing the current connection is usable or not"""
        if self.is_expired():
            return False
        try:
            self.ping()
            return True
        except:
            return False

    def close(self):
        try:
            self.transport.close()
        except Exception as err:
            logger.warn("Failed to close the connection: %r" % err)

    @property
    def TTransportException(self):
        raise NotImplementedError

    @classmethod
    def get_socket_factory(cls):
        raise NotImplementedError

    @classmethod
    def get_protocol_factory(cls):
        raise NotImplementedError

    @classmethod
    def get_transport_factory(cls):
        raise NotImplementedError

    @classmethod
    def get_thrift_client(cls, service, protocol):
        raise NotImplementedError

    @classmethod
    def set_timeout(cls, socket, timeout):
        raise NotImplementedError

    @classmethod
    def connect(cls, host, port, service, timeout=20,
                keepalive=None, service_name=None):
        """Connect to server

        :param host: the host linked to
        :param port: the TCP port linked to
        :param timeout: timeout time, seconds
        """
        socket = cls.get_socket_factory()(host, port)
        cls.set_timeout(socket, timeout * 1000)
        transport = cls.get_transport_factory()(socket)
        protocol = cls.get_protocol_factory()(transport)

        transport.open()

        return cls(
            host=host, port=port, transport=transport,
            protocol=protocol, service=service,
            keepalive=keepalive, service_name=service_name
        )

    @classmethod
    def ensure_connected(cls, host, port, service, timeout=20,
                         keepalive=None, conn_err_handler=None,
                         max_try=None, interval=0.5, pvalue=(),
                         pdict=None, service_name=None):
        """Ensure to connect to the host, after having tried the max_try, breaking out.

        :param conn_err_handler: the function, which will be executed when
                            failing to connect to the host.
        :param max_try: the max times to try to connect
        :param interval: the interval time between two connects
        :param pvalue: the params used in err_handler
        :param pdict: the params used in err_handler
        """
        if pdict is None:
            pdict = {}
        max_try = max_try or 0
        for retries in count(0):
            if max_try and retries >= max_try:
                raise RuntimeError(
                    'Max tried to connect the host, but it is unreachable.')
            try:
                return cls.connect(
                    host, port, service, timeout, keepalive, service_name)
            except Exception:
                conn_err_handler and \
                    conn_err_handler(retries, *pvalue, **pdict)
                time.sleep(interval)


class PyCyThriftClient(BaseThriftClient):
    @property
    def TTransportException(self):
        from thriftpy.transport import TTransportException
        return TTransportException

    @classmethod
    def get_socket_factory(cls):
        from thriftpy.transport import TSocket
        return TSocket

    @classmethod
    def get_protocol_factory(cls):
        from thriftpy.protocol import TCyBinaryProtocolFactory
        return TCyBinaryProtocolFactory().get_protocol

    @classmethod
    def get_transport_factory(cls):
        from thriftpy.transport import TCyBufferedTransportFactory
        return TCyBufferedTransportFactory().get_transport

    @classmethod
    def get_thrift_client(cls, service, protocol):
        from thriftpy.thrift import TClient
        client = TClient(service, protocol)
        return client

    @classmethod
    def set_timeout(cls, socket, timeout):
        socket.set_timeout(timeout)


class BaseThriftConnectionPool(object):
    def __init__(self, host, port, thrift_connection_class,
                 service, ensure_connect=False, max_try=None,
                 conn_err_handler=None, pvalue=(), pdict=None,
                 max_size=40, init_connection_size=0, timeout=20,
                 keepalive=None, service_name=None):
        if pdict is None:
            pdict = {}
        if service is None:
            raise RuntimeError('Param service should not be None.')
        assert init_connection_size <= max_size
        self.host = host
        self.port = port
        self.thrift_connection_class = thrift_connection_class
        self.ensure_connect = ensure_connect
        self.service = service
        self.max_size = max_size
        self.connection_pool = set()
        self.timeout = timeout
        self.keepalive = keepalive
        self.service_name = service_name

        # Only useful when ensure_connect=True
        if self.ensure_connect:
            self.max_try = max_try
            self.conn_err_handler = conn_err_handler
            self.pvalue = pvalue
            self.pdict = pdict

        self._init_connection(init_connection_size)

    def _init_connection(self, init_connection_size):
        for i in xrange(init_connection_size):
            self.connection_pool.add(self.create_connection())

    def pool_size(self):
        return len(self.connection_pool)

    def create_connection(self):
        """Create a connection.

        ONLY can be called when the connection pool is inaccessable
        """
        if self.ensure_connect:
            return self.thrift_connection_class.ensure_connect(
                host=self.host, port=self.port,
                service=self.service, timeout=self.timeout,
                keepalive=self.keepalive, max_try=self.max_try,
                conn_err_handler=self.conn_err_handler,
                pvalue=self.pvalue, pdict=self.pdict,
                service_name=self.service_name
            )
        return self.thrift_connection_class.connect(
            host=self.host, port=self.port,
            service=self.service, timeout=self.timeout,
            keepalive=self.keepalive, service_name=self.service_name
        )

    def _get_connection(self):
        """Get the connection from the pool,

        if there is no more connection, return None"""
        if not self.connection_pool:
            return None
        try:
            return self.connection_pool.pop()
        except KeyError:
            return None

    def get_connection_from_pool(self):
        """Get one connection from the connection pool."""
        connection = self._get_connection()
        if connection is None:
            return None
        if not connection.is_connection_available():
            connection.close()
            return None
        return connection

    def acquire_client(self):
        """get connection to the server"""
        return self.get_connection_from_pool() or self.create_connection()

    def push_new_connection(self, connection):
        """Push the new connection to connection pool."""
        assert isinstance(connection, BaseThriftClient)
        if self.max_size > 0 \
                and self.pool_size() < self.max_size:
            self.connection_pool.add(connection)

    @contextlib.contextmanager
    def connect(self):
        """Main entrypoint.

        For easy to use, use context to call.
        """
        client = self.acquire_client()
        try:
            yield client
            self.push_new_connection(client)
        except client.TTransportException:
            client.close()
            raise
        except Exception:
            self.push_new_connection(client)
            raise


def validate_host_and_port(host, port):
    if not (host and port):
        raise RuntimeError(
            'Invalid host or port: The host or port should not be None.')


class ThriftConnectionPool(BaseThriftConnectionPool):
    def __init__(self, host, port, service,
                 thrift_connection_class=PyCyThriftClient,
                 ensure_connect=False, max_try=None,
                 conn_err_handler=None, pvalue=(), pdict=None,
                 max_size=40, init_connection_size=0, instrument=True,
                 timeout=20, keepalive=None, service_name=None):
        if pdict is None:
            pdict = {}
        validate_host_and_port(host, port)
        super(ThriftConnectionPool, self).__init__(
            host=host,
            port=port,
            service=service,
            max_size=max_size,
            thrift_connection_class=thrift_connection_class,
            keepalive=keepalive,
            timeout=timeout,
            ensure_connect=ensure_connect,
            max_try=max_try,
            conn_err_handler=conn_err_handler,
            pvalue=pvalue,
            pdict=pdict,
            init_connection_size=init_connection_size,
            service_name=service_name
        )
        if instrument:
            self.metrics = Instrument(
                client=self,
                metric_key='thrift.connection.pool',
                service_name=service_name,
                type='thrift'
            )
            self.metrics.start()
