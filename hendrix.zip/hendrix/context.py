# coding: utf-8
import time

from gevent import getcurrent

from .util import cached_property


class Context(object):
    """A container can hold some relative information of the current request.

    :param api_name: the name of the api which is called.
    :param api_ctx: it holds two things:
                    1. the hostname of the request sender
                    2. the request id. Every request has a different id.
    :param api_args: the params which is needed in the method which
                     handle the request
    """
    def __init__(self, api_name, api_ctx, api_args=()):
        self.api_name = api_name
        self.api_ctx = api_ctx
        self.api_args = api_args
        self.api_started_at = 0
        self._api_cost = None
        self._api_finished = False

    @property
    def _now(self):
        return int(time.time() * 1000)

    def current_cost(self):
        return self._now - self.api_started_at

    @property
    def api_cost(self):
        if self._api_finished:
            return self._api_cost
        return self.current_cost()

    @cached_property
    def req_id(self):
        return self.api_ctx.req_id

    @cached_property
    def client_host(self):
        return self.api_ctx.client_host

    def api_start(self):
        if not self.api_started_at:
            self.api_started_at = self._now

    def api_finish(self):
        self._api_finished = True
        self._api_cost = self.current_cost()


class DummyContext(Context):
    def __init__(self, *args, **kwargs):
        self.api_name = None
        self.api_ctx = None
        self.api_args = ()

    @cached_property
    def api_cost(self):
        return 0

    @cached_property
    def req_id(self):
        return None

    @cached_property
    def client_host(self):
        return None

    def api_start(self):
        pass

    def api_finish(self):
        pass


class GlobalContext(object):
    _default_get_ident_func = lambda self: id(getcurrent())  # noqa: E731

    def __init__(self, identifier_func=None):
        self.__ident_func__ = identifier_func or self._default_get_ident_func
        self._ctx = dict()
        super(GlobalContext, self).__init__()

    def set_ctx(self, ctx):
        ident = self.__ident_func__()
        self._ctx[ident] = ctx

    def get_current_ctx(self):
        return self._ctx.get(self.__ident_func__(), None)

    def remove_ctx(self):
        self._ctx.pop(self.__ident_func__(), None)

    def __repr__(self):
        _dict = dict()
        for k, v in self._ctx.iteritems():
            _dict[k] = v
        return '<GlobalContext Object: ident_func: {}, ctx: {}>'.format(
            self.__ident_func__, _dict)

    def __str__(self):
        return self.__repr__()


g = GlobalContext()
