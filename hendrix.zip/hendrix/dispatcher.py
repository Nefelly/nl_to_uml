# coding: utf-8
import functools
import inspect
import logging
import sys

from .context import Context, g
from .log import log_api_call
from .metrics import send_api_metrics
from .signals import (
    before_api_call_started,
    after_api_call_finished,
    got_api_call_exception,
    signal_handler,
)
from .sentry import sentry_exception_handler

logger = logging.getLogger(__name__)


class DispatcherType(type):
    def __new__(mcs, name, bases, d):
        cls = type.__new__(mcs, name, bases, d)
        _methods = []
        for name, method in inspect.getmembers(cls, inspect.ismethod):
            if name == 'ping' or _is_nowrap(method):
                continue
            _methods.append(method)

            wrapped = cls._wrap(method)
            setattr(cls, name, wrapped)
        setattr(cls, '__methods__', _methods)
        return cls


_NOWRAP_ATTR = '__nowrap__'


def nowrap(method):
    setattr(method, _NOWRAP_ATTR, True)
    return method


def _is_nowrap(method):
    return getattr(method, _NOWRAP_ATTR, False)


@signal_handler()
def before_api_call_started_handler(sender, **data):
    """The function which will be called when receiving a request."""
    data['ctx'].api_start()


@signal_handler()
def after_api_call_finished_handler(sender, **data):
    """The function which will be called when after handling a request."""
    ctx = data['ctx']
    ctx.api_finish()
    send_api_metrics(ctx)
    log_api_call(logger, ctx)


@signal_handler()
def got_api_call_exception_handler(sender, **data):
    """The function which will be called when raising an exception."""
    ctx = data.get('ctx')
    exc_info = data.get('exc_info')
    exc = exc_info[1]
    warn_only = data.get('warn_only', False)

    ctx.api_finish()
    send_api_metrics(ctx, exc=True)
    log_api_call(logger, ctx, exc, warn_only)
    sentry_exception_handler(ctx, exc_info)


class APIInterfaceError(Exception):
    pass


class APIInconsistent(APIInterfaceError):
    def __init__(self, api_name_set, obj, is_dispatcher):
        head = 'Thrift File' if not is_dispatcher else 'Dispatcher'
        api_str = ''
        if isinstance(api_name_set, (set, list, tuple)):
            api_str = ', '.join(api_name_set)
        else:
            api_str = str(api_name_set)
        message = \
            '{}: lack of these APIs: {} in {}'.format(
                head, api_str, obj)
        super(APIInconsistent, self).__init__(message)


class ContextMissing(APIInterfaceError):
    def __init__(self, func_name):
        message = \
            'Func: {} need \'ctx\' param as the first param.'.format(
                func_name)
        super(ContextMissing, self).__init__(message)


class ContextRequired(APIInterfaceError):
    def __init__(self, func_name):
        message = \
            'Func: {} need \'ctx\' param to set \'required\'.'.format(
                func_name)
        super(ContextRequired, self).__init__(message)


class ParamInconsistent(APIInterfaceError):
    def __init__(self, thrift_args_num, dispatcher_args_num, api_name):
        message = \
            'Inconsistency of the number of params: ' \
            '{} in thrift file, {} in dispatcher. API: {}'.format(
                thrift_args_num, dispatcher_args_num, api_name)
        super(ParamInconsistent, self).__init__(message)


class BaseDispatcher(object):
    __metaclass__ = DispatcherType

    APIInconsistent = APIInconsistent
    ContextMissing = ContextMissing
    ContextRequired = ContextRequired
    ParamInconsistent = ParamInconsistent

    @nowrap
    def __init__(self, service):
        self.service = service
        self._register_signals()
        self._check_idl_service_consistency()

    @nowrap
    def _register_signals(self):
        """Register signals which is given in ``signals.py``"""
        before_api_call_started.connect(
            before_api_call_started_handler, self)
        after_api_call_finished.connect(
            after_api_call_finished_handler, self)
        got_api_call_exception.connect(
            got_api_call_exception_handler, self)

    @classmethod
    @nowrap
    def _wrap(cls, method):
        @functools.wraps(method)
        def wrapper(self, ctx, *args, **kwargs):
            svc = self.service
            try:
                g.set_ctx(Context(method.__name__, ctx, (args, kwargs)))
                current_ctx = g.get_current_ctx()
                before_api_call_started.send(self, ctx=current_ctx)
                rv = method(self, ctx, *args, **kwargs)
                after_api_call_finished.send(self, ctx=current_ctx)
            except svc.client_exc:
                got_api_call_exception.send(self, ctx=current_ctx,
                                            exc_info=sys.exc_info(),
                                            warn_only=True)
                raise
            except (svc.server_exc, svc.unknown_exc):
                got_api_call_exception.send(self, ctx=current_ctx,
                                            exc_info=sys.exc_info())
                raise
            except Exception as e:
                exc_info = sys.exc_info()
                typ, val, tb = exc_info
                got_api_call_exception.send(self, ctx=current_ctx,
                                            exc_info=exc_info)
                raise svc.server_exc, svc.server_exc(message=str(e)), tb
            else:
                return rv
            finally:
                g.remove_ctx()
        return wrapper

    def ping(self):
        pass

    @nowrap
    def _get_idl_api_args_num(self):
        api_dict = {}
        service = self.service.tcls
        idl_api_set = set(service.thrift_services)
        for name in idl_api_set:
            if name != 'ping':
                param_list = \
                    getattr(service, name + '_args', None).thrift_spec
                if param_list[1][1] != 'ctx':
                    raise self.ContextMissing(name)
                if param_list[1][-1] is not True:
                    raise self.ContextRequired(name)
                api_dict[name] = len(param_list)
        return api_dict

    @nowrap
    def _get_dispatcher_api_args_num(self):
        api_dict = {}
        for api in self.__methods__:
            param_list = inspect.getargspec(api).args

            if 'self' in param_list:
                param_list.remove('self')
            if param_list[0] != 'ctx':
                raise self.ContextMissing(api.__name__)
            api_dict[api.__name__] = len(param_list)
        return api_dict

    @nowrap
    def _check_api_name_consistency(self):
        """Check the consistency of api name between idl and dispatcher"""
        dispatcher_api = set([api.__name__ for api in self.__methods__])
        idl_api = set(self.service.tcls.thrift_services)
        idl_api.remove('ping')
        diff_idl_api = dispatcher_api.difference(idl_api)
        diff_dispatcher_api = idl_api.difference(dispatcher_api)
        if len(diff_idl_api) > 0:
            raise self.APIInconsistent(
                diff_idl_api, self.service.idl_module, is_dispatcher=True)
        if len(diff_dispatcher_api) > 0:
            raise self.APIInconsistent(
                diff_dispatcher_api, self, is_dispatcher=False)

    @nowrap
    def _check_api_args_consistency(self):
        """Check the number of params in every api"""
        dispatcher_api_dict = self._get_dispatcher_api_args_num()
        idl_api_dict = self._get_idl_api_args_num()
        for i_api, t_args_num in idl_api_dict.iteritems():
            d_args_num = dispatcher_api_dict[i_api]
            if t_args_num != d_args_num:
                raise self.ParamInconsistent(
                    t_args_num, d_args_num, i_api)

    @nowrap
    def _check_idl_service_consistency(self):
        """Check the consistency of apis between idl and dispatcher"""
        self._check_api_name_consistency()
        self._check_api_args_consistency()
