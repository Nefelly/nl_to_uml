# coding: utf-8
import json
import os.path
import logging

from pkg_resources import resource_string, resource_filename
import thriftpy
from thriftpy.thrift import TProcessor

from .util import import_string, cached_property
from .dispatcher import APIInterfaceError

logger = logging.getLogger(__name__)


class IDLBaseMissing(Exception):
    def __init__(self, e):
        message = '`idl_base` is a hard dependency for every thrift' \
            ' project: {}'.format(e)
        super(IDLBaseMissing, self).__init__(message)


class IDLBaseVersionTooLow(Exception):
    def __init__(self, version, min_version):
        message = \
            '`idl_base` version too low ({} < {}), please upgrade'.format(
                version, min_version)
        super(IDLBaseVersionTooLow, self).__init__(message)


class IDLHelper(object):
    IDL_ROOT = 'idl/gitlab.xiaohongshu.com'
    IDL_BASE_DIR = os.path.join(IDL_ROOT, 'sns', 'idl_base')

    IDLBaseMissing = IDLBaseMissing
    IDLBaseVersionTooLow = IDLBaseVersionTooLow

    def __init__(self, full_name, package_name, idl_dir=None):
        """Thrift service

        :param str name: name of the thrift service defined in IDL
        :param str full_name: fully qualified project name, e.g. ``sns.rps``
        :param str idl_dir: dir name under ``IDL_ROOT``
                            contaning the idl files
        """
        self.full_name = full_name
        self.package_name = package_name
        self.idl_dir = idl_dir or os.path.join(
            self.IDL_ROOT, *self.full_name.split('.', 1))
        self._check_idl_base_version()

    def _get_idl_base_version(self):
        try:
            idl_meta = json.loads(
                resource_string(self.package_name, 'idl/meta.json'))
            idl_base_version = idl_meta[
                'remotes']['gitlab.xiaohongshu.com/sns/idl_base']['version']
        except Exception as e:
            raise self.IDLBaseMissing(e)
        else:
            return idl_base_version

    def _check_idl_base_version(self):
        idl_base_version = self._get_idl_base_version()
        if idl_base_version < self.min_idl_base_version:
            raise self.IDLBaseVersionTooLow(
                idl_base_version, self.min_idl_base_version)

    @cached_property
    def min_idl_base_version(self):
        return self._get_idl_base_version()

    def _get_idl_module(self, idl_file_path, mod_name, include_dirs):
        return thriftpy.load(idl_file_path,
                             module_name=mod_name,
                             include_dirs=include_dirs)

    def _get_package_idl_module(self, idl_dir, idl_file_name, mod_name):
        idl_dir_path = resource_filename(self.package_name, idl_dir)
        include_dirs = [idl_dir_path]
        idl_file_path = os.path.join(idl_dir_path, idl_file_name)
        return self._get_idl_module(idl_file_path, mod_name, include_dirs)

    @cached_property
    def package_idl_module(self):
        idl_file_name = self.package_name + '.thrift'
        mod_name = self.package_name + '_thrift'
        return self._get_package_idl_module(
            self.idl_dir, idl_file_name, mod_name)

    @cached_property
    def idl_base_idl_module(self):
        return self.package_idl_module.idl_base


class ThriftService(object):
    def __init__(self, name, full_name, package_name,
                 dispatcher_cls, idl_dir=None):
        """Thrift service

        :param str name: name of the thrift service defined in IDL
        :param str full_name: fully qualified project name, e.g. ``sns.rps``
        :param str package_name: name of the package containing
                                 the thrift service
        :param str dispatcher_cls: name of the dispatcher class defining API to
                                   handle the request
        :param str idl_dir: dir name under ``IDLHelper.IDL_ROOT``
                            contaning the idl files
        """
        self.name = name
        self.idl_helper = IDLHelper(full_name, package_name, idl_dir)

        self.dispatcher_cls = dispatcher_cls

        self.client_exc = self._get_common_exc('ClientError')
        self.server_exc = self._get_common_exc('ServerError')
        self.unknown_exc = self._get_common_exc('UnknownError')
        self.common_excs = (self.client_exc, self.server_exc, self.unknown_exc)

    def _get_common_exc(self, exc_name):
        return getattr(self.idl_base_idl_module, exc_name)

    @cached_property
    def tcls(self):
        return getattr(self.idl_module, self.name)

    @cached_property
    def dispatcher(self):
        cls = import_string(self.dispatcher_cls)
        try:
            return cls(self)
        except APIInterfaceError as e:
            logger.error(str(e))
            raise

    @cached_property
    def idl_module(self):
        return self.idl_helper.package_idl_module

    @cached_property
    def idl_base_idl_module(self):
        return self.idl_helper.idl_base_idl_module

    @cached_property
    def tprocessor(self):
        return TProcessor(self.tcls, self.dispatcher)
