#!/usr/bin/env python
# coding: utf-8
"""
Usage:
  hen deploy <host>
  hen deploy <host> [--rev <rev-name>] [--remote-user <user>]
                    [--release-celery] [--tag <tag>] ...
                    [--yes] [--verbose]
  hen deploy <host> --list-tags
  hen deploy --install-ansible-roles [--verbose]
  hen deploy --help

Options:
  --rev <rev-name>                 Specify git revision name to deploy
                                   [default: master]
  --list-tags                      List available task tags
  --install-ansible-roles          Install required ansible roles
  --release-celery                 Release celery or not
  -t <tag ...>, --tag <tag ...>    Run deploy tasks tagged with the value
  -u <user>, --remote-user <user>  Specify remote user to run the deploy
                                   task [default: deploy]
  -y, --yes                        Answer `yes` when prompted, useful for
                                   script automation
  -v, --verbose                    Make ouput more verbose
"""
import os
from sys import stdout
import tempfile

from docopt import docopt

from .util import cd, get_repo_root, run

ANSIBLE_DIR = os.path.join(get_repo_root(), 'ansible')
DEPLOY_SERVICE_PLAYBOOK = 'service.yml'
DEPLOY_CELERY_PLAYBOOK = 'celery.yml'

INSTALL_ROLES_YML = """\
- src: git+ssh://git@gitlab.xiaohongshu.com/sns/ansible-role-hendrix.sync_code.git
  name: hendrix.sync_code
  version: master
- src: git+ssh://git@gitlab.xiaohongshu.com/sns/ansible-role-hendrix.log.git
  name: hendrix.log
  version: master
- src: git+ssh://git@gitlab.xiaohongshu.com/sns/ansible-role-hendrix.python.git
  name: hendrix.python
  version: master
- src: git+ssh://git@gitlab.xiaohongshu.com/sns/ansible-role-runit.git
  name: runit
  version: master
- src: git+ssh://git@gitlab.xiaohongshu.com/sns/ansible-role-kapacitor.git
  name: kapacitor
  version: master
- src: git+ssh://git@gitlab.xiaohongshu.com/sns/ansible-role-hendrix.service.git
  name: hendrix.service
  version: master
- src: git+ssh://git@gitlab.xiaohongshu.com/sns/ansible-role-hendrix.celery_service.git
  name: hendrix.celery_service
  version: master
"""  # noqa


def install_ansible_roles(verbose=False):
    tmpfile = tempfile.NamedTemporaryFile(prefix='hendrix_deploy_roles-',
                                          suffix='.yml')
    if verbose:
        print 'temp file name:', tmpfile.name
    with tmpfile.file as f:
        f.write(INSTALL_ROLES_YML)
        f.flush()
        if verbose:
            print 'roles to be installed: \n', INSTALL_ROLES_YML
        return run(['ansible-galaxy', 'install', '--force', '-p', 'roles',
                    '-r', tmpfile.name])


def get_tag_list(host):
    return run([
        'ansible-playbook', '-l', host,
        '--list-tags', DEPLOY_SERVICE_PLAYBOOK])


DEPLOY_INFO_HEADER_TEMPLATE = """\
# Deploying hendrix service #
---
Hosts/Groups: {host}
Version: {revision}
ansible-playbook command to run: {cmd}
---
"""
CONFIRMATION = 'Confirm to proceed? [y/N] '


def _deploy(host, playbook, revision=None, tags=None,
            remote_user=None, yes=False, verbose=False):
    """deploy asura to remote hosts"""
    cmd = ['ansible-playbook', '-l', host]
    if revision:
        cmd += ['-e', '"sync_code_git_revision={}"'.format(revision)]
    if tags:
        cmd += ['-t', ','.join(tags)]
    if remote_user:
        cmd += ['-u', remote_user]
    if verbose:
        cmd += ['-vvv']
    cmd.append(playbook)
    cmd = ' '.join(cmd)
    deploy_info_header = DEPLOY_INFO_HEADER_TEMPLATE.format(
        host=host, revision=revision, cmd=cmd)
    stdout.write(deploy_info_header)
    stdout.flush()

    if yes:
        return run(cmd, True)
    else:
        try:
            yorn = raw_input(CONFIRMATION)
        except BaseException:
            return 0
        if yorn == 'y':
            return run(cmd, True)


def deploy_service(service_host, revision=None, tags=None,
                   release_celery=False, remote_user=None,
                   yes=None, verbose=False):
    """deploy hendrix service"""
    # staging -- celery-staging
    # prod    -- celery-prod
    # deploy hendrix service
    rv = _deploy(host=service_host, revision=revision, tags=tags, yes=yes,
                 verbose=verbose, remote_user=remote_user,
                 playbook=DEPLOY_SERVICE_PLAYBOOK)
    if rv != 0:
        return rv
    if release_celery:
        celery_host = 'celery-prod' \
            if service_host == 'prod' else 'celery-staging'
        # deploy celery queue
        rv = _deploy(host=celery_host, revision=revision, tags=tags, yes=yes,
                     verbose=verbose, remote_user=remote_user,
                     playbook=DEPLOY_CELERY_PLAYBOOK)
    return rv


def main(argv=None):
    args = docopt(__doc__, argv=argv)
    with cd(ANSIBLE_DIR):
        if args['--install-ansible-roles']:
            return install_ansible_roles(args['--verbose'])
        elif args['--list-tags']:
            return get_tag_list(args['<host>'])
        else:
            return deploy_service(
                service_host=args['<host>'], revision=args['--rev'],
                tags=args['--tag'], remote_user=args['--remote-user'],
                yes=args['--yes'], verbose=args['--verbose'],
                release_celery=args['--release-celery'])
