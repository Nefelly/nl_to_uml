#!/usr/bin/env python
# coding: utf-8
"""
usage:
  hen serve
  hen serve [--dev] [--] [<gunicorn_args> ...]
  hen serve --help

options:
  --dev  Run server in dev mode
"""
import os
import sys

from docopt import docopt
from hendrix.const import ENV_DEV

from .util import cd_root


def serve(dev=False, gunicorn_args=None):
    if dev:
        os.environ['HENDRIX_ENV'] = ENV_DEV

    from hendrix.app import get_current_app

    if not gunicorn_args:
        sys.argv[1:] = []
        sys.argv.append(get_current_app()._gunicorn_thrift_entry_path)
    else:
        sys.argv[1:] = gunicorn_args

    from hendrix.gunicorn import HendrixThriftApplication
    return HendrixThriftApplication(__doc__[7:]).run()


def main(argv=None):
    args = docopt(__doc__, argv=argv)
    with cd_root():
        return serve(args['--dev'], args['<gunicorn_args>'])
