#!/usr/bin/env python
# coding: utf-8
"""
Usage:
    hen <command> [<args> ...]
    hen --help
    hen --version

Commands:
    deploy    Deploy service to remote host
    serve     Start server
"""
import sys

from docopt import docopt
import pkg_resources

from . import deploy, serve
from ..util import get_pkg_name


def main():
    version = pkg_resources.require(get_pkg_name())[0].version
    args = docopt(__doc__, options_first=True, version=version)
    argv = [args['<command>']] + args['<args>']
    rv = 0
    if args['<command>'] == 'deploy':
        rv = deploy.main(argv=argv)
    elif args['<command>'] == 'serve':
        rv = serve.main(argv=argv)
    sys.exit(rv)


if __name__ == "__main__":
    main()
