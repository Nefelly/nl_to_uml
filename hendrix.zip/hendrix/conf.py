# coding: utf-8
import os
import types

from schema import Schema, Optional, Use

from . import const
from .util import AttributeDict, concat_dict, import_string


def valid_env(e):
    return e in (const.ENV_DEV, const.ENV_PROD, const.ENV_TESTING)

_schema_common = {
    'HENDRIX_ENV': valid_env,
    Optional('HENDRIX_INTEGRATION_TYPE'): lambda s: s in [
        const.INTEGRATION_MODE_THRIFT,
        const.INTEGRATION_MODE_COMPONENT,
    ],
    Optional('HENDRIX_STAGING_HOSTNAMES', default=[
        # asura
        'sns-asura-staging',
        'sns-asura-staging02',
        'asura-staging-lhy',
        # thrift service
        'sns-service-staging',
    ]): [str],
}

_schema_thrift = {
    'HENDRIX_THRIFT_HOST': str,
    'HENDRIX_THRIFT_PORT': Use(int),
    'HENDRIX_IDL_MODULE': str,
}

_schema_comp_logging = {
    Optional('HENDRIX_LOG_DICT_CONFIG'): {valid_env: dict},
}
_schema_comp_cache = {
    Optional('CACHE_SETTINGS'): {str: dict},
    Optional('CACHE_INSTRUMENT', default=True): bool,
}
_schema_comp_database = {
    Optional('DB_SETTINGS'): {str: dict},
    Optional('REDIS_SETTINGS'): {str: dict},
}
_schema_comp_metrics = {
    Optional('METRICS_ENABLED', default=True): bool,
    Optional('METRICS_INFLUXDB_URL', default='influxdb://localhost:8086'): str,
    Optional('METRICS_SCHEMAS'): {
        str: {
            '_srv': str,
            '_opts': dict,
            'cache.op': {
                'tags': [
                    'op',
                    'hostname',
                    'server',
                    'api',
                    'timeout',
                    'exc',
                    'retry',
                ],
                'fields': [
                    'value',
                    'key',
                    'rid',
                ],
            },
            'cache.conn': {
                'tags': [
                    'server',
                    'used',
                    'hostname',
                ],
                'fields': [
                    'value',
                ],
                'precision': 's',
            },
            'redis.conn': {
                'tags': [
                    'used',
                    'hostname',
                    'server',
                    'service_name',
                ],
                'fields': [
                    'value',
                ],
                'precision': 's',
            },
            'redis.op': {
                'tags': [
                    'op',
                    'hostname',
                    'server',
                    'api',
                    'exc',
                ],
                'fields': [
                    'value',
                    'key',
                    'rid',
                ],
            },
            'mongo.ops': {
                'tags': [
                    'ns',
                    'op',
                    'ok',
                    'hostname',
                ],
                'fields': [
                    'value',
                    'rid',
                    'req_id',
                    'op_id',
                ]
            },
            Optional('thrift.connection.ops'): {
                'tags': [
                    'hostname',
                    'endpoint',
                    'service_name',
                ],
                'fields': [
                    'value',
                ],
            },
            Optional('thrift.connection.pool'): {
                'tags': [
                    'used',
                    'hostname',
                    'service_name',
                ],
                'fields': [
                    'value',
                ],
                'precision': 's',
            },
            Optional(str): dict,
        },
    },
}
_schema_comp_disco = {
    Optional('CONSUL_HOST', default='127.0.0.1'): str,
    Optional('CONSUL_PORT', default=8500): Use(int),
}
_schema_comp_mq = {
    Optional('MQ_HOST', default='sns-lb-rabbitmq.devops.xiaohongshu.com'): str,
    Optional('MQ_PORT', default=5670): Use(int),
    Optional('MQ_PRODUCER', default='producer'): str,
    Optional('MQ_PRODUCER_PASSWORD',
             default='49898228-24cf-11e7-a8a6-acbc329430af'): str,
    Optional('MQ_CONSUMER', default='consumer'): str,
    Optional('MQ_CONSUMER_PASSWORD',
             default='b8ac5a91-24d2-11e7-9101-acbc329430af'): str,
}

_schema_components = concat_dict(
    _schema_comp_logging,
    _schema_comp_cache,
    _schema_comp_metrics,
    _schema_comp_database,
    _schema_comp_disco,
    _schema_comp_mq,
)

schemas = {
    # Schema for integrating Hendrix to build a complete Thrift service
    const.INTEGRATION_MODE_THRIFT: concat_dict(
        _schema_common,
        _schema_thrift,
        _schema_components,
    ),

    # Schema for integrating Hendrix to use its various components
    const.INTEGRATION_MODE_COMPONENT: concat_dict(
        _schema_common,
        _schema_components,
    ),
}


class Setting(AttributeDict):
    _DEFAULT_SETTING_SRC = 'settings.py'
    _DEFAULT_INTEGRATION_MODE = const.INTEGRATION_MODE_THRIFT

    def __init__(self, src=None, schema=None, strict=False):
        """
        A setting object that can read framework and hosting app configs
        from either a python object or a python file

        Args:
            src: A string of filename or object reference path. Or A
                 python object.  Defaults to `settings.py`.
                 All attributes of the python object will be read in
                 excluding those start with `__`.
            schema: A dict of extra schema
            strict: A boolean value to indicate whether the presence of
                    keys other than that specified in schema is valid

        Usage::

            setting = Setting()

            # Python file
            setting.from_pyfile('yourconfig.py')

            # Python object by direct reference
            setting.from_object(setting_object)

            # Python object by string path
            setting.from_object('path.to.the.setting_object')

            # Access the setting
            setting.SOME_OPTION
            setting['SOME_OPTION']
        """
        super(Setting, self).__init__()
        self.schema_dict = None
        self._setting_src = src
        self._finalized = False
        self._extra_schema = schema or {}
        self._strict = strict
        self._integration_mode = None

    def __setattr__(self, name, value):
        object.__setattr__(self, name, value)

    def __getitem__(self, key):
        self._finalize()
        return super(Setting, self).__getitem__(key)

    def _get_source(self):
        if not self._setting_src:
            src = os.getenv(
                'HENDRIX_SETTINGS_MODULE', self._DEFAULT_SETTING_SRC)
            self._setting_src = self.HENDRIX_SETTINGS_MODULE = src
        return self._setting_src

    def _get_integration_mode(self):
        self._integration_mode = self.get('HENDRIX_INTEGRATION_MODE',
                                          self._DEFAULT_INTEGRATION_MODE)
        self.HENDRIX_INTEGRATION_TYPE = self._integration_mode
        return self._integration_mode

    def _get_schema(self):
        self.schema_dict = {}
        inte_type = self._get_integration_mode()
        self.schema_dict.update(schemas[inte_type])
        if '_extra_schema_dict' in self:
            extra_schema = dict.__getitem__(self, '_extra_schema_dict')
            self.schema_dict.update(extra_schema)
        self.schema_dict.update(self._extra_schema)
        if not self._strict:
            self.schema_dict.update({object: object})
        return Schema(self.schema_dict)

    def _update_config(self, settings_obj):
        for k, v in settings_obj.__dict__.iteritems():
            if not k.startswith('__'):
                self[k] = v
        schema = self._get_schema()
        self.update(schema.validate(self))
        self._finalized = True

    def _finalize(self):
        if self._finalized:
            return

        src = self._get_source()
        if isinstance(src, basestring) and src.endswith('.py'):
            self.from_pyfile(src)
        else:
            self.from_object(src)

    def from_object(self, obj):
        """Updates the values from the given object.  An object can be
        of one of the following two types:

        - a string, in this case the object with that name will be
          imported
        - an actual object reference: that object is used directly

        Objects are usually either modules or classes.

        Example::

            config = HendrixSetting()
            config.from_object('yourapplication.default_config')
        """
        if isinstance(obj, basestring):
            settings_obj = import_string(obj)
        else:
            settings_obj = obj
        self._update_config(settings_obj)

    def from_pyfile(self, filename):
        """
        Updates the values in the config from a Python file.  This
        function behaves as if the file was imported as module with the
        :meth:`from_object` function.

        Args:
            filename: the filename of the config.  This can either be an
                      absolute filename or a filename relative to the
                      root path of the project(recommand).
        """
        d = types.ModuleType('setting')
        d.__file__ = filename
        try:
            with open(filename) as setting_file:
                exec(
                    compile(setting_file.read(), filename, 'exec'),
                    d.__dict__
                )
        except IOError as e:
            e.strerror = 'Unable to load setting file (%s)' % e.strerror
            raise
        self.from_object(d)


setting = Setting()
"""
A setting object used by the framework and the hosting app overall.
Defaults to read a ``settings`.py` file in project root.
User can specify the module by setting the
``HENDRIX_SETTINGS_MODULE`` envvar.
"""
