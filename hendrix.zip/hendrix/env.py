# coding: utf-8
from . import const
from .conf import setting
from .util import get_hostname, memoize


def get_current_env():
    """Get current environ."""
    from .conf import setting
    return setting.HENDRIX_ENV


def is_prod_env():
    return get_current_env() == const.ENV_PROD


@memoize
def is_staging_env():
    if get_hostname() in setting.HENDRIX_STAGING_HOSTNAMES:
        return True
    return False
