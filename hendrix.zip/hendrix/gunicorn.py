# coding: utf-8
from __future__ import absolute_import

import importlib
import logging
import multiprocessing
import sys

from gunicorn.errors import AppImportError
from gunicorn_thrift.thriftapp import ThriftApplication

from .app import get_current_app
from .conf import setting
from .env import is_prod_env

logger = logging.getLogger(__name__)


def when_ready_hook(server):
    get_current_app().lifecycle.register()


def post_worker_init_hook(worker):
    if setting.get('HENDRIX_PROFILING', False):
        from . import profile
        profile.start_profiling()
    if 'DB_SETTINGS' in setting:
        get_current_app().db_manager.initall()


def worker_exit_hook(server, worker):
    from . import profile
    if setting.get('HENDRIX_PROFILING', False) or profile.yappi.is_running():
        profile.stop_profiling()


def on_exit_hook(server):
    get_current_app().lifecycle.deregister()
    if setting.get('HENDRIX_PROFILING', False):
        from . import profile
        profile.aggregate_child_process_stats()


class HendrixThriftApplication(ThriftApplication):
    def init(self, parser, opts, args):
        super_cfg = super(HendrixThriftApplication, self).init(
            parser, opts, args)
        cfg = self._get_default_setting()
        if super_cfg:
            cfg.update(super_cfg)
        return cfg

    def load_thrift_app(self):
        try:
            return super(HendrixThriftApplication, self).load_thrift_app()
        except AppImportError:
            try:
                module, obj = self.app_uri.split(':', 1)
                if '.' in obj:
                    app = importlib.import_module(module)
                    for attr in obj.split('.'):
                        app = getattr(app, attr)
                    return app
            except AttributeError:
                raise AppImportError(
                    "Failed to find application object: %r" % obj)
            else:
                raise

    def _get_default_setting(self):
        app = get_current_app()
        cfg = dict(
            proc_name=app.full_name,
            bind='{}:{}'.format(setting.HENDRIX_THRIFT_HOST,
                                setting.HENDRIX_THRIFT_PORT),
            loglevel='debug',
            worker_class='thriftpy_gevent',
            graceful_timeout=10,
            timeout=10,
            thrift_protocol_factory=  # noqa
            'thriftpy.protocol:TCyBinaryProtocolFactory',
            thrift_transport_factory=  # noqa
            'thriftpy.transport:TCyBufferedTransportFactory',
            when_ready=when_ready_hook,
            post_worker_init=post_worker_init_hook,
            worker_exit=worker_exit_hook,
            on_exit=on_exit_hook,
        )

        if is_prod_env():
            cfg.update(dict(
                workers=multiprocessing.cpu_count() * 2 + 1,
                loglevel='info'))

            if sys.platform != 'darwin':
                cfg.update(dict(
                    syslog=True,
                    syslog_addr='unix:///dev/log#dgram',
                    syslog_prefix=app.package_name,
                    syslog_facility='local6',
                ))
        return cfg
