from collections import namedtuple
import functools
import logging
import types

from bson import ObjectId
from dogpile.cache import CacheRegion
import mongoengine

from . import cache
from .exc import client_exc
from .idl import idl_base_thrift

logger = logging.getLogger(__name__)

__all__ = ['ModelRequestHandler', 'ModelListRequestHandler', 'RequestHandler',
           'BaseRequestParser', 'RequestArgument']


_text_type = lambda x: x if x != str else basestring  # noqa: E731


class RequestArgument(object):
    """The request argument class.

    :param name: the param name.
    :param type: the data type of the param. Default is string.
    :param required: the param is mandatory or not.
    :param default: the default value of the param, default is None.
    :param choices: if set, the value of param must be in this iterable.
    """
    def __init__(self, name, type=str, item_type=None, required=False,
                 default=None, choices=(), help=''):
        if item_type is not None and type not in (set, tuple, list):
            raise ValueError("Only type is (set, tuple, list), "
                             "the item_type can be used.")
        self.name = name
        self.type = _text_type(type)
        self.required = required
        self.default = default
        self.choices = choices
        self.help = help

        self.item_type = _text_type(item_type or self.type)

    def _validate_type(self, value):
        res = False
        if self.item_type == ObjectId:
            res = self.item_type.is_valid(value)
        else:
            res = isinstance(value, self.item_type)
        if not res:
            return self.handle_validate_error(TypeError, value=value)

    def _validate_choices(self, value):
        if self.choices and value not in self.choices:
            return self.handle_validate_error(ValueError, value=value)

    def validate_arg(self, value):
        if not isinstance(value, (list, set, tuple)):
            value = [value]
        for v in value:
            self._validate_type(v)
            self._validate_choices(v)

    def handle_validate_error(self, error_type, *args, **kwargs):
        """Called when an error is raised while validate.
        Developers can rewrite this function to handle the validate error.

        :param error_type: the error type which will be raised.
        :param value: the value of the handler received.
        :param msg: the error message.
        """
        value = kwargs.pop('value', None)
        msg = kwargs.pop('msg', None)
        if not msg:
            msg = 'invalid arg value: {!r}'.format((self.name, value))
        raise error_type(msg)


class BaseRequestParser(object):
    reserved_name = ['ctx', 'pagination']

    def __init__(self, argument_cls=RequestArgument):
        self.argument_dict = dict()
        self.argument_cls = argument_cls
        self._auto_load_arguments()

    def _validate_reserve(self, argument):
        if argument.name in self.reserved_name:
            raise ValueError(
                'arg name invalid: {!r}'.format(argument.name))

    def add_argument(self, *args, **kwargs):
        """Add argument to the Parser. Currently it support two ways:

            1. Accept a singal instance of argument_cls:
                parser.add_argument(
                    RequestArgument('foo', type=str, required=True))

            2. Accept a bunch of params to make an instance of arugment_cls:
                parser.add_argument('foo', type=str, required=True)
        """
        if len(args) == 1 and isinstance(args[0], self.argument_cls):
            self._validate_reserve(args[0])
            self.argument_dict[args[0].name] = args[0]
        else:
            _arg = self.argument_cls(*args, **kwargs)
            self._validate_reserve(_arg)
            self.argument_dict[_arg.name] = _arg

    def _auto_load_arguments(self):
        """Auto load argument params into the Parser class."""
        for value in self.__class__.__dict__.values():
            if isinstance(value, self.argument_cls):
                self.add_argument(value)

    def parse(self, **kwargs):
        args = {}
        for name, item in self.argument_dict.iteritems():
            try:
                value = kwargs[name]
            except KeyError:
                value = item.default
                if value is None and item.required:
                    raise client_exc.InvalidArgumentError(
                        'arg is missing: {!r}'.format(name))
            else:
                try:
                    item.validate_arg(value)
                except Exception as e:
                    if item.required or value is not None:
                        raise client_exc.InvalidArgumentError(str(e))
            args[name] = value
        return args

    def keys(self):
        return self.argument_dict.keys()


class EmptyRequestParser(BaseRequestParser):
    """Request parser for the APIs that do not have ANY params."""
    pass


class RequestCacheSetting(object):
    setting_keys = ('version', 'region', 'expiration', 'should_cache_fn')
    default_version = 'v1'
    default_expiration = 60 * 5  # 5min

    def __init__(self, setting=None):
        setting = setting or {}
        self._validate(setting)
        self.setting = setting

    def _validate(self, setting):
        for k, v in setting.iteritems():
            if k not in self.setting_keys:
                raise ValueError('invalid setting key: {!r}'.format(k))
            if k == 'version':
                if not v.startswith('v'):
                    raise ValueError('invalid cache version, e.g. `v1`')
                try:
                    int(v[1:], 10)
                except ValueError:
                    raise ValueError('invalid cache version, e.g. `v1`')
            elif k == 'region':
                if not isinstance(v, CacheRegion):
                    raise TypeError('invalid cache region')
            elif k == 'expiration':
                try:
                    int(v)
                except ValueError:
                    raise ValueError('invalid cache expiration time')
            elif k == 'should_cache_fn':
                if not callable(v):
                    raise TypeError('invalid should cache fn')

    @property
    def version(self):
        return self.setting.get('version', self.default_version)

    @property
    def region(self):
        return self.setting['region']

    @property
    def expiration(self):
        return self.setting.get('expiration', self.default_expiration)

    @property
    def should_cache_fn(self):
        return self.setting.get('should_cache_fn', cache.not_cache_none)

    def __set__(self, instance, value):
        if instance is None:
            return
        self._validate(value)
        self.setting = value

    def __get__(self, instance, owner):
        return self


class RequestHandlerMeta(type):
    def __new__(mcs, name, base, attrs):
        cls = type.__new__(mcs, name, base, attrs)
        meta = attrs.get('meta', {})
        cls.args_parser = meta.get('args_parser', EmptyRequestParser())
        cls.args_cls = namedtuple(name + 'Args', cls.args_parser.keys())
        cls.model = meta.get('model', None)
        cls.thrift_serializer = meta.get('thrift_serializer', None)
        cls.thrift_deserializer = meta.get('thrift_deserializer', None)
        cls.query_pagination = meta.get(
            'query_pagination', idl_base_thrift.Pagination())
        cls.cache_setting = \
            RequestCacheSetting(meta.get('cache_setting_dict', {}))

        return cls


class RequestHandler(object):
    __metaclass__ = RequestHandlerMeta

    def __new__(cls, ctx, pagination=None, **kwargs):
        self = super(RequestHandler, cls).__new__(
            cls, ctx, pagination, **kwargs)
        self.args = self._get_args(**kwargs)

        cache_setting = self.cache_setting

        if not cache_setting.setting:
            return self

        creator = self.handle_request
        cache_key_gen = cache._key_generator(
            cls.__name__ + '.' + cache_setting.version, creator)
        pagination = pagination or self.query_pagination

        kw = self.args._asdict()
        if pagination:
            kw['_pagination_page'] = pagination.page
            kw['_pagination_page_size'] = pagination.page_size
        key = cache_key_gen(**kw)

        @functools.wraps(creator)
        def cached_creator(handler):
            return cache_setting.region.get_or_create(
                key, creator, cache_setting.expiration,
                cache_setting.should_cache_fn)

        self.handle_request = types.MethodType(cached_creator, self, cls)
        return self

    def __init__(self, ctx, pagination=None, **kwargs):
        self.ctx = ctx
        self.pagination = pagination or self.query_pagination
        self.clean()

    def _get_args(self, **kwargs):
        args = self.args_parser.parse(**kwargs)
        return self.args_cls(**args)

    def clean(self):
        pass

    def serialize(self, value):
        # pylint: disable=E1102
        return self.thrift_serializer(value)
        # pylint: enable=E1102

    def handle_request(self):
        """The entrance of handle the request. It will handle the request and

        serialize it if ``thrift_serializer`` is given in ``handler_meta``.

        Developers can write in ``dispatcher.py`` like this::

            def some_method_in_dispatcher_cls(self, ctx, *args, **kwargs):
                return FooRequestHandler(ctx, **kwargs).handle_request()
        """
        res = self.handle()
        if self.thrift_serializer:
            return self.serialize(res)
        return res

    def handle(self):
        """The backend function to handle the request.

        Developers can rewrite it.
        """
        raise NotImplementedError


class ModelHandlerMixin(object):
    query_only_fields = []
    query_sort_fields = []

    @property
    def qs(self):
        if hasattr(self, 'model'):
            return self.model.objects
        return None

    def handle_request(self):
        try:
            res = super(ModelHandlerMixin, self).handle_request()
        except mongoengine.NotUniqueError as e:
            raise client_exc.ItemAlreadyExistError(str(e))
        except mongoengine.ValidationError as e:
            raise client_exc.InvalidArgumentError(str(e))
        except mongoengine.DoesNotExist as e:
            raise client_exc.ItemNotFoundError(str(e))
        else:
            return res


class ModelListHandlerMixin(ModelHandlerMixin):
    @property
    def qs(self):
        if hasattr(self, 'model'):
            return self.model.objects
        return None

    def handle(self):
        qs = self.qs

        # determine page size
        page_size = self.pagination.page_size
        if not qs._limit:
            page_size = min(page_size, idl_base_thrift.MAX_PAGE_SIZE)
        else:
            page_size = min(qs._limit, idl_base_thrift.MAX_PAGE_SIZE)
        qs = qs.limit(page_size)

        # determine offset
        skip = page_size * (self.pagination.page - 1)
        if skip > 0:
            qs = qs.skip(skip)

        # only include specified fields (if any)
        if self.query_only_fields and not qs._loaded_fields.fields:
            qs = qs.only(*self.query_only_fields)

        # sort
        if self.query_sort_fields:
            qs = qs.order_by(*self.query_sort_fields)
        return qs


class ModelRequestHandler(ModelHandlerMixin, RequestHandler):
    pass


class ModelListRequestHandler(ModelListHandlerMixin, RequestHandler):
    pass
