# coding: utf-8
import functools
import logging

from blinker import Namespace

logger = logging.getLogger(__name__)

_signals = Namespace()

# the signal which will be triggered when receiving a request and
# before handling it.
before_api_call_started = _signals.signal('before-api-call-started')

# the signal which will be triggered when after handling a request
after_api_call_finished = _signals.signal('after-api-call-finished')

# the signal which will be triggered when raising an exception
got_api_call_exception = _signals.signal('got-api-call-exception')


def _handle_exc(func, sender, **data):
    logger.exception('error handling signal: %r', func.func_name)


def signal_handler(exc_handler=_handle_exc):
    def wrapped(func):
        @functools.wraps(func)
        def handler(sender, **data):
            try:
                return func(sender, **data)
            except Exception:
                exc_handler(func, sender, **data)
        return handler
    return wrapped
