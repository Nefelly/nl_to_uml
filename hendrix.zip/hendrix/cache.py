# coding: utf-8
import base64
import functools
import inspect
import itertools
import json
import logging
from StringIO import StringIO
import socket
import warnings
import zlib

from bson import ObjectId
from dogpile.cache import (
    make_region,
    register_backend,
)
from dogpile.cache.compat import pickle
from dogpile.cache.backends.memcached import GenericMemcachedBackend
from dogpile.cache.util import memoized_property
import gevent
import gevent.socket
import gevent.lock
import pymemcache.client
from pymemcache import exceptions as mcexc

from . import util
from .conf import setting
from .context import g
from .metrics import Instrument, Timing, send_cache_op_metrics
from .util import BaseDBManager

FLAG_STRING = 1 << 0
FLAG_PICKLE = 1 << 1
FLAG_INTEGER = 1 << 2
FLAG_NONE = 1 << 3
FLAG_PICKLE_COMPRESSED = 1 << 4
FLAG_JSON = 1 << 5
FLAG_JSON_COMPRESSED = 1 << 6

COMPRESSION_THRESHOLD = 128
CACHE_OP_MAX_RETRY_COUNT = 3

logger = logging.getLogger(__name__)


def _make_pymemcache_client(opts):
    """According to the settings, creating the instance to connect the memcache.
    If ``instrument is True``, means it need to collect metrics about the
    memcache connection pool, It will spawn a background greenlet to send
    metrics data to the influxdb.
    """
    instrument = opts.pop('instrument', False)
    server = util.dsn2srv(opts['url'])
    client = RetryWithFallbackProxy(
        server=server,
        max_pool_size=opts.get('max_pool_size', 10),
        serializer=serializer,
        deserializer=deserializer,
        connect_timeout=opts.get('connect_timeout', 1.0),
        timeout=opts.get('timeout', 0.5),
        no_delay=opts.get('no_delay', True),
        ignore_exc=opts.get('ignore_exc', False),
        key_prefix=opts.get('key_prefix', ''),
        socket_module=gevent.socket,
        lock_generator=gevent.lock.BoundedSemaphore,
        default_noreply=False,
    )
    if instrument:
        client.instrument = Instrument(
            client=client,
            metric_key='cache.conn',
            type='memcache',
            server=server)
        client.instrument.start()
    return client


class PymemcacheBackend(GenericMemcachedBackend):
    def __init__(self, arguments):
        super(PymemcacheBackend, self).__init__(arguments)
        self.settings = arguments

    def _imports(self):
        global pymemcache
        import pymemcache
        import pymemcache.client

    def _create_client(self):
        return _make_pymemcache_client(self.settings)

    @memoized_property
    def client(self):
        return self._create_client()


register_backend('hendrix.cache.pymemcache', __name__, 'PymemcacheBackend')


class SerdeError(Exception):
    def __init__(self, message, e=None, eobj=None):
        super(SerdeError, self).__init__(message)
        self.e = e
        self.eobj = eobj

    def __str__(self):
        return '{}: {}'.format(self.message, self.e)


def _compress(str_):
    try:
        return zlib.compress(str_)
    except Exception as e:
        raise SerdeError('error compress', e, str_)


def _decompress(value):
    try:
        return zlib.decompress(value)
    except Exception as e:
        raise SerdeError('error decompress', e, value)


def _pickle(obj):
    try:
        output = StringIO()
        pickler = pickle.Pickler(output, 0)
        pickler.dump(obj)
        return output.getvalue()
    except Exception as e:
        raise SerdeError('error pickle', e, obj)


def _unpickle(str_):
    try:
        buf = StringIO(str_)
        unpickler = pickle.Unpickler(buf)
        return unpickler.load()
    except Exception as e:
        raise SerdeError('error unpickle', e, str_)


def _jsonify(dict_):
    return json.dumps(
        dict_, ensure_ascii=True, indent=None, separators=(',', ':'))


def serializer(key, value):
    def _maybe_compress_value(value):
        if len(value) > COMPRESSION_THRESHOLD:
            return True, _compress(value)
        return False, value

    if isinstance(value, str):
        flag = FLAG_STRING
    elif isinstance(value, int):
        flag = FLAG_INTEGER
    elif isinstance(value, dict):
        flag = FLAG_JSON
        compressed, value = _maybe_compress_value(_jsonify(value))
        if compressed:
            flag = FLAG_JSON_COMPRESSED
    else:
        flag = FLAG_PICKLE
        compressed, value = _maybe_compress_value(_pickle(value))
        if compressed:
            flag = FLAG_PICKLE_COMPRESSED
    return value, flag


def deserializer(key, value, flag):
    if flag == FLAG_NONE:
        return None
    if flag == FLAG_STRING:
        return value
    if flag == FLAG_INTEGER:
        return int(value)
    if flag == FLAG_JSON:
        return json.loads(value)
    if flag == FLAG_JSON_COMPRESSED:
        return json.loads(_decompress(value))
    if flag == FLAG_PICKLE:
        return _unpickle(value)
    if flag == FLAG_PICKLE_COMPRESSED:
        return _unpickle(_decompress(value))
    return None


class BaseMemcacheClientProxy(object):
    """A base proxy class. When calling the attribute of
    the instance whose bases class contains ``BaseMemcacheClientProxy``,
    it actually calls the attribute in ``_proxied``
    """
    _proxied_cls = None
    _proxied_methods = []

    def __init__(self, *args, **kwargs):
        # pylint: disable=not-callable
        self._proxied = self._proxied_cls(*args, **kwargs)
        # pylint: enable=not-callable

        for to_proxy in self._proxied_methods:
            meth_name = to_proxy[0]
            wrapped = self._wrap(to_proxy)
            object.__setattr__(self, meth_name, wrapped)

    def __getattr__(self, name):
        return getattr(self._proxied, name)

    def _wrap(self, method_name):
        raise NotImplementedError


class RetryWithFallbackProxy(BaseMemcacheClientProxy):
    """the connection pool of pymemcache is in the Back of this proxy,
    all the operations will be sent to the pymemcache. And all the
    operations support retry strategy if not being executed successfully.
    """
    # pylint: disable=no-method-argument
    def _none(*args, **kwargs):
        return None

    def _false(*args, **kwargs):
        return False

    def _empty_dict(*args, **kwargs):
        return {}
    # pylint: enable=no-method-argument

    _QUERY_BATCH_COUNT = 20
    _proxied_cls = pymemcache.client.PooledClient
    _proxied_methods = [
        ('get', _none),
        ('set', _false),
        ('get_many', _empty_dict),
        ('get_multi', _empty_dict),
        ('set_many', _false),
        ('set_multi', _false),
        ('delete', _false),
        ('delete_many', _false),
        ('delete_multi', _false),
    ]
    _multi_methods = (
        'get_many', 'get_multi', 'set_many',
        'set_multi', 'delete_many', 'delete_multi'
    )

    _unrecoverable_exc = (
        mcexc.MemcacheIllegalInputError,
        mcexc.MemcacheUnknownError,
        SerdeError,
    )
    """Exceptions that won't be retried when catched"""

    def __init__(self, *args, **kwargs):
        self._retry_count = kwargs.pop('retry_count', 1)
        super(RetryWithFallbackProxy, self).__init__(*args, **kwargs)

    def _exec_cache_op(self, op_method, *args, **kwargs):
        method_name = op_method.__name__
        err_log = functools.partial(logger.exception, 'error %r cache: %r %r',
                                    method_name, args, kwargs)
        warn_log = functools.partial(
            logger.warning, 'failed to %r cache: %r %r', method_name, args,
            kwargs, exc_info=True)

        try:
            with gevent.Timeout(self._proxied.timeout):
                return op_method(*args, **kwargs)
        except self._unrecoverable_exc as e:
            err_log()
            return e
        except RuntimeError as e:
            warn_log()
            if e.args and e.args[0].startswith('Too many objects'):
                mc_pool = self._proxied.client_pool
                if not mc_pool._free_objs and \
                        len(mc_pool._used_objs) >= mc_pool.max_size:
                    mc_pool.clear()
            return e
        except (
            socket.timeout,
            gevent.Timeout,
            mcexc.MemcacheError,
            socket.error,
        ) as e:
            warn_log()
            return e

    def _exec_with_metrics(self, fallback, method,
                           method_name, *args, **kwargs):
        res = None

        for i in itertools.count():
            if i > self._retry_count:
                break
            is_retry = i > 0
            if is_retry:
                logger.info('retry %r cache: %r %r',
                            method_name, args, kwargs)

            try:
                t = Timing(None)
                t.begin()
                res = self._exec_cache_op(method, *args, **kwargs)
                t.end()

                is_exc = isinstance(res, BaseException)
                is_timeout = is_exc and isinstance(
                    res, (socket.timeout, gevent.Timeout))
                send_cache_op_metrics(
                    g.get_current_ctx(), method_name,
                    self._proxied.server, args, t.value, is_exc,
                    is_timeout, is_retry)

                if not is_exc:
                    return res

                if isinstance(res, self._unrecoverable_exc):
                    break
            except Exception as e:
                res = e
                logger.exception(
                    'error %r cache: %r %r', method_name, args, kwargs)
                break

        logger.warning('falling back for %r cache: %r %r with %r',
                       method_name, args, kwargs, fallback)
        return fallback(res, *args, **kwargs)

    def _exec_get_many(self, req_args, fallback, method,
                       method_name, **kwargs):
        total = len(req_args)
        _tmp = total / self._QUERY_BATCH_COUNT
        pages = _tmp if total % self._QUERY_BATCH_COUNT == 0 else _tmp + 1
        res = {}
        for page in range(pages):
            start = page * self._QUERY_BATCH_COUNT
            end = (page + 1) * self._QUERY_BATCH_COUNT
            _res = self._exec_with_metrics(
                fallback, method, method_name,
                req_args[start:end], **kwargs
            )
            if isinstance(_res, dict):
                res.update(_res)
        return res

    def _exec_set_many(self, req_args, fallback, **kwargs):
        res = True
        for key, value in req_args.iteritems():
            res = self._exec_with_metrics(
                fallback, self._proxied.set, 'set',
                key, value, **kwargs
            )
            if not res:
                break
        return res

    def _exec_delete_many(self, req_args, fallback, **kwargs):
        res = True
        for key in req_args:
            res = self._exec_with_metrics(
                fallback, self._proxied.delete,
                'delete', key, **kwargs
            )
        return res

    def retry_with_fallback(self, fallback, method):
        method_name = method.__name__

        @functools.wraps(method)
        def wrapper(*args, **kwargs):
            if method_name not in self._multi_methods:
                res = self._exec_with_metrics(
                    fallback, method, method_name, *args, **kwargs)
            else:
                if method_name.startswith('get'):
                    res = self._exec_get_many(
                        args[0], fallback, method, method_name, **kwargs)
                elif method_name.startswith('set'):
                    res = self._exec_set_many(args[0], fallback, **kwargs)
                elif method_name.startswith('delete'):
                    res = self._exec_delete_many(args[0], fallback, **kwargs)
            return res
        return wrapper

    def _wrap(self, method):
        method_name, fallback = method
        op_method = getattr(self._proxied, method_name)
        return self.retry_with_fallback(fallback, op_method)


def _format_all_args(*args, **kwargs):
    arg_values = []
    for v in sorted(list(args) + kwargs.values()):
        if isinstance(v, unicode):
            v = v.encode('utf-8')
        elif isinstance(v, ObjectId):
            v = str(v)
        arg_values.append(v)
    return ','.join(repr(v) for v in arg_values)


def _key_general_setting(namespace, fn):
    if namespace is None:
        tmpl = '{modname}:{fname}'
    else:
        tmpl = '{modname}:{fname}|{namespace}'
    if inspect.ismethod(fn):
        modname = getattr(fn.__self__, '__module__', fn.im_class.__module__)
    else:
        modname = fn.__module__
    prefix = tmpl.format(
        modname=modname,
        fname=fn.__single_cache_name__ if
        hasattr(fn, '__single_cache_name__') else fn.__name__,
        namespace=namespace,
    )
    argspec = inspect.getargspec(fn)
    is_meth = argspec.args and argspec.args[0] in ('self', 'cls', 'kls')
    return prefix, is_meth


def _generate_params_string(arg_str, key_pat, prefix):
    """Use the params to generate ``variables_string``

    part in the cache key.
    """
    key_str = key_pat.format(
        prefix=prefix, arg_str=base64.b64encode(arg_str))
    if len(key_str) > 250:
        key_comp = zlib.compress(arg_str)
        key_str = key_pat.format(
            prefix=prefix, arg_str=base64.b64encode(key_comp))
    return key_str


def _key_generator(namespace, fn, **kwargs):
    """The memcache key generator. The format is::

        '{module_name}:{function_name}|{namespace}|{variables_string}'

    Developers can give the namespace, if not given, the key will be::

        '{module_name}:{function_name}|{variables_string}'

    """
    prefix, is_meth = _key_general_setting(namespace, fn)
    key_pat = '{prefix}|{arg_str}'

    def to_string(*args, **kwargs):
        if is_meth:
            args = args[1:]
        arg_str = _format_all_args(*args, **kwargs)
        return _generate_params_string(arg_str, key_pat, prefix)
    return to_string


def _multi_key_generator(namespace, fn, **kwargs):
    """The memcache multi-keys generator. It will return a ``List``,
    The format is::

        ['{module_name}:{function_name}|{namespace}|{variables_string}', ...]

    Developers can give the namespace, if not given, the key will be::

        ['{module_name}:{function_name}|{variables_string}', ...]

    """
    prefix, is_meth = _key_general_setting(namespace, fn)
    key_pat = '{prefix}|{arg_str}'

    def to_string(key):
        arg_str = _format_all_args(key)
        return _generate_params_string(arg_str, key_pat, prefix)

    def generate_key(*args, **kwargs):
        if kwargs:
            raise ValueError(
                "dogpile.cache's default key creation "
                "function does not accept keyword arguments.")
        if is_meth:
            args = args[1:]

        return [key for key in map(to_string, args)]
    return generate_key


DEFAULT_REGION_EXPIRATION_TIME = 60 * 5  # 5m
DEFAULT_REGION_NAME = 'default'


def not_cache_none(value):
    """The function to set a strategy to tell under what
    circumstances not to cache the value in memcache
    """
    return value is not None


class CacheMixinType(type):
    """The Meta class of the CacheMixinType class."""
    DEFAULT_CACHE_VERSION = 'v1'

    def __new__(mcs, name, bases, d):
        cls = type.__new__(mcs, name, bases, d)
        if name == 'CacheMixin':
            return cls
        cache_meta = d.get('cache_meta', {})
        client = cache_meta.get('client', None)
        if not client:
            warnings.warn('no cache client set, cache wrapping'
                          ' will not be carried out for %s' % name)
            return cls

        def set_cache(exp, meth_name, is_multi, should_cache_fn):
            ns = (cache_meta.get('namespace', name) + '.' +
                  cache_meta.get('version', mcs.DEFAULT_CACHE_VERSION))
            if is_multi:
                return client.cache_multi(
                    exp, meth_name, namespace=ns,
                    should_cache_fn=should_cache_fn,
                    region_name=cache_meta.get(
                        'region', DEFAULT_REGION_NAME))(method)
            return client.cache(
                exp, namespace=ns, should_cache_fn=should_cache_fn,
                region_name=cache_meta.get(
                    'region', DEFAULT_REGION_NAME))(method)

        exp_conf = cache_meta.get('exp', {})
        should_cache_fn = cache_meta.get('should_cache_fn', not_cache_none)

        def predicate(member):
            return (inspect.ismethod(member) and
                    not member.__name__.startswith('_') and
                    member.__name__ in d)

        for meth_name, method in inspect.getmembers(cls, predicate):
            exp = exp_conf.get(meth_name, None) or exp_conf.get('*', None)
            exp_multi = exp_conf.get(meth_name + ':multi', None)
            is_multi = False
            if exp_multi:
                exp = exp_multi[0]
                is_multi = True
            elif exp is None:
                default_exp = DEFAULT_REGION_EXPIRATION_TIME
                warnings.warn(
                    'no expiration time set for %s.%s, use'
                    ' default (%ds)' % (name, meth_name, default_exp))
                exp = default_exp
            fn_cache_name = exp_multi[1] \
                if isinstance(exp_multi, tuple) else meth_name
            wrapped = set_cache(
                exp, fn_cache_name, is_multi, should_cache_fn)

            setattr(cls, meth_name, wrapped)
        return cls


class CacheMixin(object):
    """ The Mixin class which aims to help to make memcache automatically.
    It uses just like setting meta class in MongoEngine::

        class TableNameQuerySet(CacheMixin, QuerySet):
            cache_meta = {
                'client': cache_client,
                'version': 'v1',
                'exp': {
                    '*': 60 * 15,
                    'with_id': 60 * 60,
                    'with_ids:multi': (60 * 15, 'with_id'),
                },
            }

            def with_id(self, id):
                return super(TableNameQuerySet, self).with_id(id)

            def with_ids(self, *ids):
                # doing something

    when calling :meth:`with_id`, it will first try to get the value from
    memecache, if get nothing, then it will execute the function and cache
    the value. Then return the value

    The cache_meta dict has three parts:

    -   client: the instance of the cache client,
                always ``session['cache_name']``
    -   version: the version string
    -   exp: it is a dict object, this dict contains the expire time of every
             function which want to be cached. The key is the name of the
             function, the value is the expire time(Second)

             -  '*': it cover all functions in this class
             -  function_name: it will assign expire time(the value of this
                               key) to this function
             -  "function_name:multi": this means this function will cache
                                       multi-values, and the value is a tuple:
                - the first value is the expire time
                - the second value means use this value as the function name to
                  generate the memcache key

    When using cache multi-values, it will find the values from memecache
    according to variables, and then passing the variables to the function
    which cannot find in memecache and executing it.
    """
    __metaclass__ = CacheMixinType


class Client(object):
    """The raw cache client. In order to use it, the developers should make
    a client first::

        session['cache_name'].make_client()
        cache_client = session['cache_name'].client

    or::

        cache_client = session['cache_name'].make_client()

    And use this raw cache client will like this::

        cache_client.set(key_name, value, timeout)
        cache_client.get(key_name)

    JUST LIKE operating pymemcache
    """
    def __init__(self, name, settings):
        self.name = name
        self._settings = settings
        self._regions = {}
        self.client = None

    def _get_wrap(self):
        wrap = []
        return wrap

    def make_region(self, name=DEFAULT_REGION_NAME,
                    expiration_time=DEFAULT_REGION_EXPIRATION_TIME):
        if name not in self._regions:
            self._regions[name] = make_region(
                name=name,
                function_key_generator=_key_generator,
                function_multi_key_generator=_multi_key_generator
            ).configure(
                'hendrix.cache.pymemcache',
                expiration_time=expiration_time,
                arguments=self._settings,
                wrap=self._get_wrap(),
            )
        return self._regions[name]

    def cache(self, expiration_time=None, region_name=DEFAULT_REGION_NAME,
              namespace=None, should_cache_fn=None):
        region = self.make_region(region_name)

        def wrapper(func):
            return region.cache_on_arguments(
                namespace=namespace,
                expiration_time=expiration_time,
                should_cache_fn=should_cache_fn)(func)
        return wrapper

    def cache_multi(self, expiration_time=None, fn_cache_name=None,
                    region_name=DEFAULT_REGION_NAME, namespace=None,
                    should_cache_fn=None):
        region = self.make_region(region_name)
        cache_multi_on_args = region.cache_multi_on_arguments(
            namespace=namespace, expiration_time=expiration_time,
            should_cache_fn=should_cache_fn)

        def wrap(func):
            @functools.wraps(func)
            def wrapped(qs, *args):
                if not hasattr(wrapped, '__cached_func'):

                    @functools.wraps(func)
                    def inner(*keys):
                        return func(qs, *keys)

                    inner.__single_cache_name__ = fn_cache_name
                    wrapped.__cached_func = cache_multi_on_args(inner)
                return wrapped.__cached_func(*args)
            return wrapped
        return wrap

    def make_client(self):
        if not self.client:
            self.client = _make_pymemcache_client(self._settings)
        return self.client


class Session(BaseDBManager):
    """The developers' entrance to get the memcache"""
    @property
    def settings(self):
        return setting.CACHE_SETTINGS

    def _initdb(self, name):
        if name not in self.settings:
            raise RuntimeError(
                'cache {!r} not configured, check `CACHE_SETTINGS`'.
                format(name))
        self[name] = Client(name, self.settings[name])


session = Session()
