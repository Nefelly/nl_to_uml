# coding: utf-8
ENV_PROD = 'prod'
ENV_TESTING = 'testing'
ENV_DEV = 'dev'

INTEGRATION_MODE_THRIFT = 'thrift'
INTEGRATION_MODE_COMPONENT = 'component'
