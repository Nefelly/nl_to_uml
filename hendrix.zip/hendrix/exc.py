# coding: utf-8
from .util import Enum
from .idl import idl_base_thrift

errcode = idl_base_thrift.ErrorCode
client_exc_cls = idl_base_thrift.ClientError
server_exc_cls = idl_base_thrift.ServerError
unknown_exc_cls = idl_base_thrift.UnknownError


class BaseError(object):
    errcode = None
    msg_pat = None

    def __init__(self, message='', errcode=None, args=(), **kwargs):
        if not message and (self.msg_pat and args):
            message = self.msg_pat % args
        errcode = errcode or self.errcode
        super(BaseError, self).__init__(errcode, message)

    def __str__(self):
        return unicode(self.message)

    def __repr__(self):
        return u'{}({}, {})'.\
            format(self.__class__.__name__, self.errcode, self.message).\
            encode('utf-8')


class ClientError(BaseError, client_exc_cls):
    errcode = errcode.ClientError


class InvalidArgumentError(ClientError):
    errcode = errcode.InvalidArgument
    msg_pat = 'invalid argument: %r'


class ItemNotFoundError(ClientError):
    errcode = errcode.ItemNotFound
    msg_pat = '%r not found'


class ItemAlreadyExistError(ClientError):
    errcode = errcode.ItemAlreadyExist
    msg_pat = '%r already existed'


client_exc = Enum(
    ('ClientError', ClientError),
    ('InvalidArgumentError', InvalidArgumentError),
    ('ItemNotFoundError', ItemNotFoundError),
    ('ItemAlreadyExistError', ItemAlreadyExistError),
)


class ServerError(BaseError, server_exc_cls):
    errcode = errcode.ServerError

server_exc = Enum(
    ('ServerError', ServerError),
)


class UnknownError(BaseError, unknown_exc_cls):
    errcode = errcode.UnknownError

unknown_exc = Enum(
    ('UnknownError', UnknownError),
)
