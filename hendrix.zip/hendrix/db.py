import logging

import mongoengine
from pymongo import monitoring

from .util import BaseDBManager
from .conf import setting
from .metrics import metrics
from .context import g

logger = logging.getLogger(__name__)


class DBManager(BaseDBManager):
    _DEFAULT_PYMONGO_OPTION = {
        'socketTimeoutMS': 1000,
        'connectTimeoutMS': 1000,
        'serverSelectionTimeoutMS': 1000,
        'minPoolSize': 1,
        'maxPoolSize': 10,
        'waitQueueMultiple': 5,
        'waitQueueTimeoutMS': 1000,
        'maxIdleTimeMS': 1000 * 60 * 10,  # 10 min
    }

    @property
    def default_pymongo_option(self):
        return self._DEFAULT_PYMONGO_OPTION.copy()

    @property
    def settings(self):
        try:
            return setting.DB_SETTINGS
        except KeyError:
            raise KeyError('Cannot find \'DB_SETTINGS\' in settings.')

    def _initdb(self, name):
        if self.get(name) is not None:
            logger.warning('db: %s has already inited.', name)
            return
        opts = self.default_pymongo_option
        opts.update(self.settings[name])
        self[name] = mongoengine.connect(**opts)
        logger.info('%r inited', mongoengine.connection._connections[
            opts.get('alias', mongoengine.connection.DEFAULT_CONNECTION_NAME)])


class CommandLogger(monitoring.CommandListener):
    def _send_metric(self, evt, ok):
        ns = ''
        if ok and 'cursor' in evt.reply:
            ns = evt.reply['cursor']['ns']
        ctx = g.get_current_ctx()
        metrics['mongo.ops'].\
            tags(ns=ns, op=evt.command_name, ok=ok,
                 hostname=metrics.HOSTNAME).\
            values(rid=ctx.req_id if ctx is not None else '',
                   req_id=evt.request_id,
                   op_id=evt.operation_id).\
            commit(evt.duration_micros / 1000)

    def started(self, evt):
        pass

    def succeeded(self, evt):
        self._send_metric(evt, True)

    def failed(self, evt):
        self._send_metric(evt, False)


monitoring.register(CommandLogger())
