# coding: utf-8
import logging
import datetime
from bson import ObjectId

from .util import unix_ts_utc

logger = logging.getLogger(__name__)


class ThriftSerializerFactory(object):
    """The factory class to generate serializer and deserializer for thrift.

    Currently, the relationship between serializer and deserializer is :

    1. Serialize
    |-------------|   serialize    |----------------------|
    | Dict Object | =============> | Thrift Struct Object |
    |-------------|                |----------------------|
    |-------------------|   serialize    |----------------------|
    | Mongo Data Object | =============> | Thrift Struct Object |
    |-------------------|                |----------------------|

    2. Deserialize:
    |----------------------|   Deserialize    |-------------|
    | Thrift Struct Object | ===============> | Dict Object |
    |----------------------|                  |-------------|

    How to use it?

    1. If you want a serializer, operating like this:

        serializer = ThriftSerializerFactory(rus_thrift.User).get_serializer()
        user_obj = serializer(user_dict)

    2. If you want a deserializer, operating like this:

        deserializer = ThriftSerializerFactory(rus_thrift.User).\
            get_deserializer()
        user_dict = deserializer(user_obj)
    """
    def __init__(self, thrift_type, clean_func=None,
                 get_attr_list_func=None, serializer_class=None,
                 deserializer_class=None):
        self.thrift_type = thrift_type
        self.clean = clean_func or self._clean
        self._serializer_class = serializer_class
        self._deserializer_class = deserializer_class
        self._get_attr_list = get_attr_list_func or self._get_attr_key_list

    def _clean(self, obj):
        pass

    def _get_attr_key_list(self, thrift_obj):
        """Get the attrs list of the thrift_obj"""
        return thrift_obj._tspec.keys()

    def _gen_serialize(self, obj, **kwargs):
        """The general serialize function"""
        if self._serializer_class is not None:
            return self._serializer_class(obj).serialize(
                self.thrift_type, **kwargs)

        self.clean(obj)
        if isinstance(obj, dict):
            return self._dict_serialize(obj)
        return self._mongo_serialize(obj)

    def _dict_serialize(self, dict_obj):
        """Serialize a dict object into a thrift object"""
        rv = self.thrift_type()
        for key in dict_obj:
            if key not in rv._tspec:
                continue
            setattr(rv, key, dict_obj[key])
        return rv

    def _mongo_serialize(self, mongo_obj):
        """Serialize a mongo data object into a thrift object"""
        rv = self.thrift_type()
        for key in mongo_obj._fields:
            if key not in rv._tspec:
                continue
            value = getattr(mongo_obj, key, None)
            if isinstance(value, ObjectId):
                value = str(value)
            elif isinstance(value, datetime.datetime):
                value = unix_ts_utc(value)
            setattr(rv, key, value)
        return rv

    def _gen_deserialize(self, thrift_obj, **kwargs):
        """The general deserialize function"""
        if self._deserializer_class is not None:
            return self._deserializer_class().deserialize(thrift_obj, **kwargs)

        dict_data = {}
        if thrift_obj is None:
            return dict_data
        self.clean(thrift_obj)
        for key in self._get_attr_list(thrift_obj):
            value = getattr(thrift_obj, key, None)
            if value is not None:
                dict_data[key] = value
        return dict_data

    def get_serializer(self):
        """Generating a serializer."""
        return self._gen_serialize

    def get_deserializer(self):
        """Generating a deserializer."""
        return self._gen_deserialize


def serialize_object_id(ser, rv, field, value):
    return str(value)


def serialize_datetime(ser, rv, field, value):
    return unix_ts_utc(value)


class BaseThriftSerializer(object):
    """The base class to convert a mongo object into a thrift struct.

    Usage::

        class ThriftSerializer(BaseThriftSerializer):
            def serialize_varialble(self, obj, key, value):
                # do something
                return value

        serializer = ThriftSerializer(mongo_object).data

    """
    _serialize_object_id = serialize_object_id
    _serialize_datetime = serialize_datetime

    def __init__(self, obj):
        self.obj = obj
        self._dict = {}
        if hasattr(self, 'clean') and callable(self.clean):
            self.clean()

    def _get_value_from_python_object_by_specname(self, specname):
        """A function to get value from python object by tspec name"""
        if isinstance(self.obj, dict):
            return self.obj.get(specname)
        else:
            return getattr(self.obj, specname, None)

    def serialize(self, thrift_type, **kwargs):
        """Go through thrift type, make sure all specs are serialized"""
        rv = thrift_type()
        self._dict = kwargs

        for _spec in rv._tspec:
            value = self._get_value_from_python_object_by_specname(_spec)
            f = getattr(self, 'serialize_' + _spec, None)
            if not f:
                if isinstance(value, ObjectId):
                    f = self._serialize_object_id
                elif isinstance(value, datetime.datetime):
                    f = self._serialize_datetime
                else:
                    setattr(rv, _spec, value)
                    continue
            try:
                ser_res = f(rv, _spec, value)
                setattr(rv, _spec, ser_res)
            except Exception:
                logger.exception('error serializing: %r %r into: %r',
                                 self.obj, (_spec, value), rv)
        return rv


class BaseThriftDeserializer(object):
    """The base class to convert a thrift struct object into a dict.
    """
    def _get_keys(self, thrift_obj):
        """Get the attrs list of the thrift_obj"""
        return thrift_obj._tspec.keys()

    def _set_attr(self, thrift_obj, dict_data):
        if thrift_obj is None:
            return dict_data
        for key in self._get_keys(thrift_obj):
            f = getattr(self, 'deserialize_' + key, None)
            if not f:
                value = thrift_obj.__dict__[key]
                if value is not None:
                    dict_data[key] = value
                continue
            try:
                value = f(key, dict_data, thrift_obj)
                if value is not None:
                    dict_data[key] = value
            except Exception:
                logger.exception(
                    'error deserializeing: %r into %r',
                    (key, value), dict_data)

    def deserialize(self, thrift_obj):
        """Thrift object => Dict object"""
        dict_data = {}
        if hasattr(self, 'clean') and callable(self.clean):
            self.clean(thrift_obj)
        self._set_attr(thrift_obj, dict_data)
        return dict_data
