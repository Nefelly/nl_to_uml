# coding: utf-8
import logging

from thriftpy.rpc import make_server
import pkg_resources

from .conf import setting
from .db import DBManager
from .service import LifeCycle
from .util import cached_property, import_string

logger = logging.getLogger(__name__)

_app = None


def get_current_app():
    try:
        ep = list(pkg_resources.iter_entry_points('hendrix', 'thrift_app'))[0]
    except IndexError:
        ep = list(pkg_resources.iter_entry_points('hendrix', 'web_app'))[0]
        app = ep.resolve()
    else:
        app = ep.load()
    _set_current_app(app)
    return app


def _set_current_app(app):
    global _app
    if not _app:
        _app = app
    return _app


class HendrixApp(object):
    log_cls = 'hendrix.log.Logging'

    def __init__(self, full_name, package_name, log_cls=None):
        """
        Hendrix app

        :param str full_name: fully qualified project name, e.g. ``sns.rps``
        :param str package_name: name of the package containing the
                                 app, e.g. ``rps``
        :param str log_cls: log class, defaults to ``hendrix.log.Logging``,
                            user defined one should inherit the default
        """
        self.full_name = full_name
        self.package_name = package_name

        self.log_cls = log_cls or self.log_cls
        self.log.setup()
        self.logger = logging.getLogger(self.package_name)
        if 'DB_SETTINGS' in setting:
            self.db_manager = DBManager()
        self.lifecycle = LifeCycle(self.full_name)

    @cached_property
    def log(self):
        cls = import_string(self.log_cls)
        return cls(self.package_name)


class HendrixThriftApp(HendrixApp):
    thrift_service_cls = 'hendrix.thrift.ThriftService'

    def __init__(self, full_name, package_name, tservice_name,
                 dispatcher_cls=None, thrift_service_cls=None,
                 idl_dir=None, log_cls=None):
        """
        Hendrix thrift app

        :param str full_name: fully qualified project name, e.g. ``sns.rps``
        :param str package_name: name of the package containing the
                                 app, e.g. ``rps``
        :param str tservice_name: name of the thrift service defined in IDL
        :param str dispatcher_cls: name of the dispatcher class that will
                                   handle the thrift request, defaults to
                                   ``<package_name>.dispatcher.Dispatcher``
        :param str thrift_service_cls: name of the thrift service
                                       class, defaults to
                                       ``hendrix.thrift.ThriftService``
        :param str idl_dir: name of the dir containing the IDL
        :param str log_cls: log class, defaults to ``hendrix.log.Logging``,
                            user defined one should inherit the default
        """
        super(HendrixThriftApp, self).__init__(
            full_name, package_name, log_cls=log_cls)

        self.tservice_name = tservice_name
        self.idl_dir = idl_dir

        self.dispatcher_cls = dispatcher_cls or \
            '.'.join([self.package_name, 'dispatcher', 'Dispatcher'])
        self.thrift_service_cls = thrift_service_cls or self.thrift_service_cls

        self._gunicorn_thrift_entry_path = \
            '{}.app:app.gunicorn_thrift_entry'.format(self.package_name)

    @cached_property
    def service(self):
        cls = import_string(self.thrift_service_cls)
        return cls(self.tservice_name, self.full_name, self.package_name,
                   self.dispatcher_cls, self.idl_dir)

    @cached_property
    def service_dispatcher(self):
        return self.service.dispatcher

    @cached_property
    def gunicorn_thrift_entry(self):
        return self.service.tprocessor

    def serve(self, host=None, port=None):
        host = host or setting.HENDRIX_THRIFT_HOST
        port = port or setting.HENDRIX_THRIFT_PORT
        server = make_server(
            self.service.tcls,
            self.service_dispatcher,
            setting.HENDRIX_THRIFT_HOST,
            setting.HENDRIX_THRIFT_PORT)
        logger.info('thrift server listening on: %s:%s', host, port)
        server.serve()
