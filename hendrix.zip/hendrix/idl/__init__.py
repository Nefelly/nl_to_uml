from ..conf import setting
from ..util import import_string

idl_base_thrift = import_string(setting.HENDRIX_IDL_MODULE).idl_base
