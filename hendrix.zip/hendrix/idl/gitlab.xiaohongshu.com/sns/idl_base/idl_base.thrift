namespace py sns.idl.base

const i16 MAX_PAGE_NUM = 200
const i16 MAX_PAGE_SIZE = 100

typedef string UUID
typedef i64 Timestamp
typedef string ObjectId

struct Context {
  1: required UUID req_id,
  2: optional string client_host,
}

struct Pagination {
  1: optional i16 page = 1,
  2: optional i16 page_size = 10,
}

enum ErrorCode {
  # client error code
  ClientError = 1000,
  InvalidArgument = 1001,
  ItemNotFound = 1002,
  ItemAlreadyExist = 1003,

  # server error code
  ServerError = 2000,

  # unknown error code
  UnknownError = 9999
}

exception ClientError {
  1: required ErrorCode errcode = ErrorCode.ClientError,
  2: optional string message,
  3: optional string display
}

exception ServerError {
  1: required ErrorCode errcode = ErrorCode.ServerError,
  2: optional string message,
  3: optional string display
}

exception UnknownError {
  1: required ErrorCode errcode = ErrorCode.UnknownError,
  2: optional string message,
  3: optional string display,
}

service BaseService {
  void ping()
}
