# internal (test) use only
namespace py hendrix

include "../idl_base/idl_base.thrift"

struct ExtraInfo {
    1: optional string desc,
    2: optional string weixin,
    3: optional i32 salary,
}

struct Person {
    1: required string name,
    2: optional string id,
    3: optional i32 age,
    4: optional string job,
    5: optional string email,
    6: optional ExtraInfo extra_info,
    7: optional i32 birthday,
}

service PingPongService extends idl_base.BaseService {}

service PersonService extends idl_base.BaseService {
    string hello(
        1: required idl_base.Context ctx
    ) throws (
        1: idl_base.ClientError ce,
        2: idl_base.ServerError se,
        3: idl_base.UnknownError ue),

    string echo_name(
        1: required idl_base.Context ctx
        2: required string name 
    ) throws (
        1: idl_base.ClientError ce,
        2: idl_base.ServerError se,
        3: idl_base.UnknownError ue),

}

