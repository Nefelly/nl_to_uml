# coding: utf-8
import logging

import consul

from .conf import setting
from .env import is_prod_env, is_staging_env
from .util import get_hostname

logger = logging.getLogger(__name__)


class LifeCycle(object):
    def __init__(self, service):
        self.name = service
        if is_staging_env():
            self.name += '-staging'
        self.id = self._gen_service_id()
        self.consul = consul.Consul(host=setting.CONSUL_HOST,
                                    port=setting.CONSUL_PORT)

    def _gen_service_id(self):
        return '_'.join([
            get_hostname(),
            str(setting.HENDRIX_THRIFT_PORT),
            self.name,
        ])

    def _get_check(self):
        return consul.Check.tcp(
            host=setting.HENDRIX_THRIFT_HOST,
            port=setting.HENDRIX_THRIFT_PORT,
            interval='1s',
            timeout='100ms',
        )

    def _get_tags(self):
        tags = ['thrift']
        if is_staging_env():
            tags.extend(['staging'])
        elif is_prod_env():
            tags.extend(['prod'])
        tags.append('-'.join(tags))
        return tags

    def register(self):
        try:
            check = self._get_check()
            tags = self._get_tags()
            logger.info('registering service: id: %s addr: :%d tags: %s'
                        ' check: %s',
                        self.id, setting.HENDRIX_THRIFT_PORT, tags, check)
            return self.consul.agent.service.register(
                self.name,
                service_id=self.id,
                port=setting.HENDRIX_THRIFT_PORT,
                check=check,
                tags=tags,
            )
        except Exception:
            logger.exception('error registering service: %r %r',
                             self.name, self.id)
            return False

    def deregister(self):
        try:
            logger.info('deregistering service: id: %r addr: :%s',
                        self.id, setting.HENDRIX_THRIFT_PORT)
            return self.consul.agent.service.deregister(self.id)
        except Exception:
            logger.exception('error deregistering service: %r %r',
                             self.name, self.id)
            return False
