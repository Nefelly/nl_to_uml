# coding: utf-8
import logging

from raven import Client as SentryClient
from raven.transport.gevent import GeventedHTTPTransport

from .conf import setting
from .env import is_prod_env, is_staging_env
from .util import get_hostname, memoize

logger = logging.getLogger(__name__)


@memoize
def _get_env():
    if is_prod_env():
        if not is_staging_env():
            return 'prod'
        else:
            return 'staging'
    return get_hostname()

sentry_client = SentryClient(dsn=setting.SENTRY_DSN,
                             transport=GeventedHTTPTransport,
                             auto_log_stacks=True,
                             enable_breadcrumbs=False,
                             environment=_get_env())


def sentry_exception_handler(ctx, exc_info):
    if setting.SENTRY_ENABLED:
        try:
            sentry_client.context.merge(_prepare_sentry_context(ctx))
            sentry_client.captureException(exc_info=exc_info)
        except Exception:
            logger.warning('error sending sentry report')
        finally:
            sentry_client.context.clear()


def _prepare_sentry_context(ctx):
    """
    extract info for sentry report
    :param ctx: request context
    :return:
    """
    return {
        'tags': {
            'api_name': ctx.api_name,
            'client_host': ctx.client_host,
        },
        'extra': {
            'req_id': ctx.req_id,
            'api_args': ctx.api_args,
            'api_cost': ctx.api_cost,
        }
    }
